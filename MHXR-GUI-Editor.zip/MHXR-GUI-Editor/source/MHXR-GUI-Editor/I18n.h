#pragma once

#include <string>

// Key based localization.
//
// UI code never contains literal text, it only asks for a key:
//     ImGui::MenuItem(I18n::T("menu.file.open"));
//
// The actual text lives in ./lang/<language>.toml, so adding a language means
// dropping in one more file - no code changes, no rebuild.
//
// Lookup order: current language -> English -> the key itself.
// Returning the key on a miss makes untranslated strings obvious on screen
// instead of showing an empty label.
namespace I18n {
    // Language codes match Settings::Language ("zh", "en").
    // Loads both zh and en up front so switching language at runtime is instant.
    void init(const std::string& language);

    void set_language(const std::string& language);
    [[nodiscard]] const std::string& current_language();

    // Text for the given key. Never returns nullptr.
    [[nodiscard]] const char* T(const char* key);

    // Wide (UTF-16) version for Win32 APIs such as file dialogs.
    // The result is cached, keep it for immediate use only.
    [[nodiscard]] const wchar_t* TW(const char* key);
}
