#include "pch.h"
#include "GUIEditor.h"

#include <algorithm>


void GUIEditor::render_texture_viewer() {
    if (m_selected_texture == -1 || m_selected_texture >= m_file.m_textures.size()) {
        return;
    }

    const auto& tex = m_file.m_textures[m_selected_texture];

    if (!tex.RenderTexture.is_valid()) {
        ImGui::TextColored({ 1.0f, 0.2f, 0.2f, 1.0f }, "%s", I18n::T("error.texture.load_failed"));

        const std::string error = texture_error_text(tex);
        if (!error.empty()) {
            ImGui::TextWrapped("%s", error.c_str());
        } else {
            ImGui::TextWrapped("%s", I18n::T("error.texture.hint"));
        }

        return;
    }

    const float width = static_cast<float>(tex.Width);
    const float height = static_cast<float>(tex.Height);

    ImGui::SliderFloat(I18n::T("texture.zoom"), &m_texture_zoom, 10.0f, 300.0f, "%.0f%%");

    if (ImGui::IsItemEdited()) {
        m_texture_fit = false;
    }

    ImGui::SameLine();

    if (ImGui::Button(I18n::T("texture.fit"))) {
        m_texture_fit = true;
    }

    ImGui::SameLine();
    ImGui::Text("%dx%d", tex.Width, tex.Height);

    float scale = m_texture_zoom / 100.0f;

    if (m_texture_fit) {
        // Measured after the controls, so the image fills what is actually left over.
        // Small textures are never blown up beyond their real size.
        const ImVec2 avail = ImGui::GetContentRegionAvail();
        scale = std::min(std::min(avail.x / width, avail.y / height), 1.0f);
        m_texture_zoom = scale * 100.0f;
    }

    ImGui::Image(tex.RenderTexture.get_view().Get(), ImVec2{ width * scale, height * scale });

    if (ImGui::IsItemHovered()) {
        const ImVec2 pos = ImGui::GetWindowPos();
        const ImVec2 padding = ImGui::GetStyle().WindowPadding;
        const ImVec2 mouse = ImGui::GetMousePos();
        const ImVec2 relpos = {
            (mouse.x - (pos.x + padding.x)) / scale,
            (mouse.y - (pos.y + padding.y) - 25.0f) / scale // TODO: Find out where that extra 25 is coming from
        };

        ImGui::SetTooltip("(%.2f, %.2f)", relpos.x, relpos.y);
    }
}
