#include "pch.h"
#include "GUIFile.h"
#include "GUITypes.h"
#include "Console.h"

#include <fmt/format.h>

#include <filesystem>
#include <ranges>
#include <cctype>
#include <vector>

GUIFile::GUIFile() = default;

void GUIFile::load_from(BinaryReader& stream) {
    // Keep the original bytes around so saving can patch them instead of rebuilding the file
    m_original.resize(stream.size());
    stream.seek_absolute(0);
    if (!m_original.empty()) {
        stream.read_bytes(m_original);
        stream.seek_absolute(0);
    }

    m_animations.clear();
    m_sequences.clear();
    m_objects.clear();
    m_obj_sequences.clear();
    m_init_params.clear();
    m_params.clear();
    m_keys.clear();
    m_instances.clear();
    m_flows.clear();
    m_flow_processes.clear();
    m_textures.clear();
    m_font_filters.clear();
    m_messages.clear();
    m_resources.clear();
    m_general_resources.clear();
    m_vertices.clear();

    struct MiniHeader {
        u32 magic;
        Version version;
    };

    const auto mini_header = stream.read<MiniHeader>();
    if (mini_header.magic != 0x495547) {
        spdlog::error("Invalid GUI file magic: {:08X}", mini_header.magic);
        return;
    }

    stream.seek_absolute(0);

    if (mini_header.version == Version::MHW) { // ---------------------------- MHW
        m_header = stream.read<GUIHeader>();
        const auto& header = m_header;

        std::memcpy(m_magic.data(), header.fileType, m_magic.size());
        m_version = header.guiVersion;
        m_attr = header.attr;
        m_revision_time = header.revisionDate;
        m_instance_id = header.instanceID;
        m_flow_id = header.flowID;
        m_variable_id = header.variableID;
        m_start_instance_index = header.startInstanceIndex;

        stream.seek_absolute(static_cast<s64>(header.animationOffset));
        for (auto i = 0u; i < header.animationNum; ++i) {
            m_animations.emplace_back(GUIAnimation::read(stream, static_cast<s64>(header.stringOffset)));
        }

        stream.seek_absolute(static_cast<s64>(header.sequenceOffset));
        for (auto i = 0u; i < header.sequenceNum; ++i) {
            m_sequences.emplace_back(GUISequence::read(stream, static_cast<s64>(header.stringOffset)));
        }

        stream.seek_absolute(static_cast<s64>(header.objectOffset));
        for (auto i = 0u; i < header.objectNum; ++i) {
            m_objects.emplace_back(GUIObject::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.objSequenceOffset));
        for (auto i = 0u; i < header.objSequenceNum; ++i) {
            m_obj_sequences.emplace_back(GUIObjectSequence::read(stream));
        }

        stream.seek_absolute(static_cast<s64>(header.initParamOffset));
        for (auto i = 0u; i < header.initParamNum; ++i) {
            m_init_params.emplace_back(GUIInitParam::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.paramOffset));
        for (auto i = 0u; i < header.paramNum; ++i) {
            m_params.emplace_back(GUIParam::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.instanceOffset));
        for (auto i = 0u; i < header.instanceNum; ++i) {
            m_instances.emplace_back(GUIInstance::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.flowOffset));
        for (auto i = 0u; i < header.flowNum; ++i) {
            m_flows.emplace_back(GUIFlow::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.flowProcessOffset));
        for (auto i = 0u; i < header.flowProcessNum; ++i) {
            m_flow_processes.emplace_back(GUIFlowProcess::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.textureOffset));
        for (auto i = 0u; i < header.textureNum; ++i) {
            m_textures.emplace_back(GUITexture::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.fontFilterOffset));
        for (auto i = 0u; i < header.fontFilterNum; ++i) {
            m_font_filters.emplace_back(GUIFontFilter::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.messageOffset));
        for (auto i = 0u; i < header.messageNum; ++i) {
            m_messages.emplace_back(GUIMessage::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.guiResourceOffset));
        for (auto i = 0u; i < header.guiResourceNum; ++i) {
            m_resources.emplace_back(GUIResource::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.generalResourceOffset));
        for (auto i = 0u; i < header.generalResourceNum; ++i) {
            m_general_resources.emplace_back(GUIGeneralResource::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.keyOffset));
        for (auto i = 0u; i < header.keyNum; ++i) {
            m_keys.emplace_back(GUIKey::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.vertexOffset));

        if (header.vertexBufferSize % GUIVertex::size != 0) {
            spdlog::error("Vertex buffer size is not a multiple of vertex size");
        }

        for (auto i = 0u; i < header.vertexBufferSize / GUIVertex::size; ++i) {
            m_vertices.emplace_back(GUIVertex::read(stream));
        }
    } else if (mini_header.version == Version::MHGU) { // ---------------------------- MHGU
        m_header_mhgu = stream.read<GUIHeaderMHGU>();
        const auto& header = m_header_mhgu;

        std::memcpy(m_magic.data(), header.fileType, m_magic.size());
        m_version = header.guiVersion;
        m_attr = header.attr;
        m_revision_time = header.revisionDate;
        m_instance_id = header.instanceID;
        m_flow_id = header.flowID;
        m_variable_id = header.variableID;
        m_start_instance_index = header.startInstanceIndex;

        stream.seek_absolute(header.animationOffset);
        for (auto i = 0u; i < header.animationNum; ++i) {
            m_animations.emplace_back(GUIAnimation::read_mhgu(stream, header.stringOffset));
        }

        stream.seek_absolute(header.sequenceOffset);
        for (auto i = 0u; i < header.sequenceNum; ++i) {
            m_sequences.emplace_back(GUISequence::read_mhgu(stream, header.stringOffset));
        }

        stream.seek_absolute(header.objectOffset);
        for (auto i = 0u; i < header.objectNum; ++i) {
            m_objects.emplace_back(GUIObject::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.objSequenceOffset);
        for (auto i = 0u; i < header.objSequenceNum; ++i) {
            m_obj_sequences.emplace_back(GUIObjectSequence::read_mhgu(stream));
        }

        stream.seek_absolute(header.initParamOffset);
        for (auto i = 0u; i < header.initParamNum; ++i) {
            m_init_params.emplace_back(GUIInitParam::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.paramOffset);
        for (auto i = 0u; i < header.paramNum; ++i) {
            m_params.emplace_back(GUIParam::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.instanceOffset);
        for (auto i = 0u; i < header.instanceNum; ++i) {
            m_instances.emplace_back(GUIInstance::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.flowOffset);
        for (auto i = 0u; i < header.flowNum; ++i) {
            m_flows.emplace_back(GUIFlow::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.flowProcessOffset);
        for (auto i = 0u; i < header.flowProcessNum; ++i) {
            m_flow_processes.emplace_back(GUIFlowProcess::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.textureOffset);
        for (auto i = 0u; i < header.textureNum; ++i) {
            m_textures.emplace_back(GUITexture::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.fontFilterOffset);
        for (auto i = 0u; i < header.fontFilterNum; ++i) {
            m_font_filters.emplace_back(GUIFontFilter::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.messageOffset);
        for (auto i = 0u; i < header.messageNum; ++i) {
            m_messages.emplace_back(GUIMessage::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.guiResourceOffset);
        for (auto i = 0u; i < header.guiResourceNum; ++i) {
            m_resources.emplace_back(GUIResource::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.generalResourceOffset);
        for (auto i = 0u; i < header.generalResourceNum; ++i) {
            m_general_resources.emplace_back(GUIGeneralResource::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.keyOffset);
        for (auto i = 0u; i < header.keyNum; ++i) {
            m_keys.emplace_back(GUIKey::read_mhgu(stream, header));
        }

        stream.seek_absolute(header.vertexOffset);

        if (header.vertexBufferSize % GUIVertex::size != 0) {
            spdlog::error("Vertex buffer size is not a multiple of vertex size");
        }

        for (auto i = 0u; i < header.vertexBufferSize / GUIVertex::size; ++i) {
            m_vertices.emplace_back(GUIVertex::read(stream));
        }
    } else if (mini_header.version == Version::MHXR) { // ------------------------ MHXR (Monster Hunter Explore)
        m_header = stream.read<GUIHeader>();
        const auto& header = m_header;

        std::memcpy(m_magic.data(), header.fileType, m_magic.size());
        m_version = header.guiVersion;
        m_attr = header.attr;
        m_revision_time = header.revisionDate;
        m_instance_id = header.instanceID;
        m_flow_id = header.flowID;
        m_variable_id = header.variableID;
        m_start_instance_index = header.startInstanceIndex;

        stream.seek_absolute(static_cast<s64>(header.animationOffset));
        for (auto i = 0u; i < header.animationNum; ++i) {
            m_animations.emplace_back(GUIAnimation::read(stream, static_cast<s64>(header.stringOffset)));
        }

        stream.seek_absolute(static_cast<s64>(header.sequenceOffset));
        for (auto i = 0u; i < header.sequenceNum; ++i) {
            m_sequences.emplace_back(GUISequence::read_mhxr(stream));
        }

        stream.seek_absolute(static_cast<s64>(header.objectOffset));
        for (auto i = 0u; i < header.objectNum; ++i) {
            m_objects.emplace_back(GUIObject::read_mhxr(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.objSequenceOffset));
        for (auto i = 0u; i < header.objSequenceNum; ++i) {
            m_obj_sequences.emplace_back(GUIObjectSequence::read(stream));
        }

        stream.seek_absolute(static_cast<s64>(header.initParamOffset));
        for (auto i = 0u; i < header.initParamNum; ++i) {
            m_init_params.emplace_back(GUIInitParam::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.paramOffset));
        for (auto i = 0u; i < header.paramNum; ++i) {
            m_params.emplace_back(GUIParam::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.instanceOffset));
        for (auto i = 0u; i < header.instanceNum; ++i) {
            m_instances.emplace_back(GUIInstance::read_mhxr(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.flowOffset));
        for (auto i = 0u; i < header.flowNum; ++i) {
            m_flows.emplace_back(GUIFlow::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.flowProcessOffset));
        for (auto i = 0u; i < header.flowProcessNum; ++i) {
            m_flow_processes.emplace_back(GUIFlowProcess::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.textureOffset));
        for (auto i = 0u; i < header.textureNum; ++i) {
            m_textures.emplace_back(GUITexture::read_mhxr(stream, header));
        }

        // MHXR: font section (24B per entry: ID, pad12, PathOff, pad4)
        stream.seek_absolute(static_cast<s64>(header.fontOffset));
        for (auto i = 0u; i < header.fontNum; ++i) {
            const u32 id = stream.read<u32>();
            stream.seek_relative(12);
            const u32 path_off = stream.read<u32>();
            stream.seek_relative(4);
            m_fonts.push_back({ id, stream.abs_offset_read_string(header.stringOffset + path_off) });
        }

        stream.seek_absolute(static_cast<s64>(header.fontFilterOffset));
        for (auto i = 0u; i < header.fontFilterNum; ++i) {
            m_font_filters.emplace_back(GUIFontFilter::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.messageOffset));
        for (auto i = 0u; i < header.messageNum; ++i) {
            m_messages.emplace_back(GUIMessage::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.guiResourceOffset));
        for (auto i = 0u; i < header.guiResourceNum; ++i) {
            m_resources.emplace_back(GUIResource::read_mhxr(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.generalResourceOffset));
        for (auto i = 0u; i < header.generalResourceNum; ++i) {
            m_general_resources.emplace_back(GUIGeneralResource::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.keyOffset));
        for (auto i = 0u; i < header.keyNum; ++i) {
            m_keys.emplace_back(GUIKey::read(stream, header));
        }

        stream.seek_absolute(static_cast<s64>(header.vertexOffset));
        constexpr u32 mhxr_vertex_size = static_cast<u32>(GUIVertex::size_mhxr);
        if (header.vertexBufferSize % mhxr_vertex_size != 0) {
            spdlog::error("Vertex buffer size is not a multiple of MHXR vertex size");
        }
        for (auto i = 0u; i < header.vertexBufferSize / mhxr_vertex_size; ++i) {
            m_vertices.emplace_back(GUIVertex::read_mhxr(stream));
        }

        // Sections that are not parsed yet: keep their raw bytes so that saving is lossless.
        const auto read_raw = [&stream](u64 begin, u64 end) {
            std::vector<u8> out;
            if (begin == 0 || end <= begin || begin >= stream.size() || end > stream.size()) {
                return out;
            }

            out.resize(static_cast<size_t>(end - begin));
            stream.seek_absolute(static_cast<s64>(begin));
            stream.read_bytes(out);
            return out;
        };

        m_raw_flow_input       = read_raw(header.flowInputOffset, header.flowSwitchOffset);
        m_raw_flow_switch      = read_raw(header.flowSwitchOffset, header.flowFunctionOffset);
        m_raw_flow_function    = read_raw(header.flowFunctionOffset, header.actionOffset);
        m_raw_action           = read_raw(header.actionOffset, header.inputConditionOffset);
        m_raw_input_condition  = read_raw(header.inputConditionOffset, header.switchOperatorOffset);
        m_raw_switch_operator  = read_raw(header.switchOperatorOffset, header.switchConditionOffset);
        m_raw_switch_condition = read_raw(header.switchConditionOffset, header.variableOffset);
        m_raw_variable         = read_raw(header.variableOffset, header.textureOffset);
    } else {
        spdlog::error("Invalid GUI file version: {:08X}", (u32)mini_header.version);
        return;
    }

    // Remember the original bytes of every parameter value so edits can be detected on save
    snapshot_param_values();

    // Determine instance root(s)
    for (size_t i = 0; i < m_instances.size(); ++i) {
        const auto& inst = m_instances[i];
        const bool is_child_instance = std::ranges::any_of(m_instances, [i, &inst](const GUIInstance& other) {
            if (other.ID == inst.ID) {
                return false;
            }

            return other.ChildIndex == static_cast<s32>(i) || other.NextIndex == static_cast<s32>(i);
        });

        if (!is_child_instance) {
            m_root_instances.push_back(inst.Index);
        }
    }
}

static std::vector<u8> param_value_bytes(const GUIParam& param) {
    std::vector<u8> out;

    if (std::holds_alternative<std::vector<u8>>(param.Values)) {
        const auto& values = std::get<std::vector<u8>>(param.Values);
        out.assign(values.begin(), values.end());
    } else if (std::holds_alternative<std::vector<u32>>(param.Values)) {
        const auto& values = std::get<std::vector<u32>>(param.Values);
        out.resize(values.size() * sizeof(u32));
        for (size_t i = 0; i < values.size(); ++i) {
            std::memcpy(out.data() + i * sizeof(u32), &values[i], sizeof(u32));
        }
    } else if (std::holds_alternative<std::vector<f32>>(param.Values)) {
        const auto& values = std::get<std::vector<f32>>(param.Values);
        out.resize(values.size() * sizeof(f32));
        for (size_t i = 0; i < values.size(); ++i) {
            std::memcpy(out.data() + i * sizeof(f32), &values[i], sizeof(f32));
        }
    } else if (std::holds_alternative<std::vector<vector4>>(param.Values)) {
        const auto& values = std::get<std::vector<vector4>>(param.Values);
        out.resize(values.size() * sizeof(vector4));
        for (size_t i = 0; i < values.size(); ++i) {
            std::memcpy(out.data() + i * sizeof(vector4), &values[i], sizeof(vector4));
        }
    }

    return out;
}

void GUIFile::snapshot_param_values() {
    m_param_value_snapshot.clear();
    m_param_value_snapshot.reserve(m_params.size());

    for (const auto& param : m_params) {
        const auto bytes = param_value_bytes(param);

        u64 base = 0;
        switch (param.ValueOffsetType) {
            case KeyValueType::KV8:   base = m_header.keyValue8Offset; break;
            case KeyValueType::KV32:  base = m_header.keyValue32Offset; break;
            case KeyValueType::KV128: base = m_header.keyValue128Offset; break;
            default: base = 0; break;
        }

        if (bytes.empty() || base == 0 || param.OrgValueOffset == 0xFFFFFFFF) {
            m_param_value_snapshot.emplace_back();
            continue;
        }

        const auto offset = static_cast<size_t>(base + param.OrgValueOffset);
        if (offset + bytes.size() > m_original.size()) {
            m_param_value_snapshot.emplace_back();
            continue;
        }

        m_param_value_snapshot.emplace_back(
            m_original.begin() + static_cast<ptrdiff_t>(offset),
            m_original.begin() + static_cast<ptrdiff_t>(offset + bytes.size())
        );
    }
}

void GUIFile::diff_param_values() const {
    for (size_t i = 0; i < m_params.size() && i < m_param_value_snapshot.size(); ++i) {
        const auto& param = m_params[i];
        const auto& old_bytes = m_param_value_snapshot[i];

        if (old_bytes.empty()) {
            continue;
        }

        const auto new_bytes = param_value_bytes(param);
        if (new_bytes.size() != old_bytes.size() || new_bytes == old_bytes) {
            continue;
        }

        u64 base = 0;
        switch (param.ValueOffsetType) {
            case KeyValueType::KV8:   base = m_header.keyValue8Offset; break;
            case KeyValueType::KV32:  base = m_header.keyValue32Offset; break;
            case KeyValueType::KV128: base = m_header.keyValue128Offset; break;
            default: continue;
        }

        FieldChange change{
            .Path = fmt::format("Params[{}] {}", i, param.Name),
            .OldValue = "original bytes",
            .NewValue = "edited bytes",
            .Offset = base + param.OrgValueOffset,
            .Bytes = new_bytes,
            // The value might be shared with other parameters, so warn about it
            .Risk = 1
        };

        bool replaced = false;
        for (auto& existing : m_changes) {
            if (existing.Path == change.Path) {
                existing = std::move(change);
                replaced = true;
                break;
            }
        }

        if (!replaced) {
            m_changes.push_back(std::move(change));
        }
    }
}

void GUIFile::record_u32(const std::string& path, u64 offset, u32 old_value, u32 new_value, int risk) {
    if (old_value == new_value) {
        return;
    }

    FieldChange change{
        .Path = path,
        .OldValue = std::to_string(old_value),
        .NewValue = std::to_string(new_value),
        .Offset = offset,
        .Risk = risk
    };

    const u32 value = new_value;
    const auto* bytes = reinterpret_cast<const u8*>(&value);
    change.Bytes.assign(bytes, bytes + sizeof(u32));

    // Replace an earlier edit of the very same field
    for (auto& existing : m_changes) {
        if (existing.Path == path && existing.Offset == offset) {
            existing = std::move(change);
            return;
        }
    }

    m_changes.push_back(std::move(change));
}

void GUIFile::record_f32(const std::string& path, u64 offset, f32 old_value, f32 new_value, int risk) {
    if (old_value == new_value) {
        return;
    }

    FieldChange change{
        .Path = path,
        .OldValue = std::to_string(old_value),
        .NewValue = std::to_string(new_value),
        .Offset = offset,
        .Risk = risk
    };

    const f32 value = new_value;
    const auto* bytes = reinterpret_cast<const u8*>(&value);
    change.Bytes.assign(bytes, bytes + sizeof(f32));

    for (auto& existing : m_changes) {
        if (existing.Path == path && existing.Offset == offset) {
            existing = std::move(change);
            return;
        }
    }

    m_changes.push_back(std::move(change));
}

void GUIFile::clear_changes() {
    m_changes.clear();
}

void GUIFile::set_view_size(u32 width, u32 height) {
    if (is_mhgu()) {
        m_header_mhgu.viewSize_Width = width;
        m_header_mhgu.viewSize_Height = height;
        return;
    }

    m_header.viewSize_Width = width;
    m_header.viewSize_Height = height;
}

namespace {
    namespace fs = std::filesystem;

    // Lowercase, all separators normalized to '\'
    std::string normalize_path(std::string path) {
        for (char& c : path) {
            if (c == '/') {
                c = '\\';
            } else {
                c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            }
        }

        return path;
    }

    bool has_extension(const fs::path& path, std::string_view extension) {
        return normalize_path(path.extension().string()) == extension;
    }

    // The .dds when present, otherwise the .tex, otherwise an empty path
    fs::path probe_texture(const fs::path& root, const std::string& texture_path) {
        fs::path base = root / texture_path;

        fs::path dds = base;
        dds.replace_extension("dds");
        if (exists(dds)) {
            return dds;
        }

        fs::path tex = base;
        tex.replace_extension("tex");
        if (exists(tex)) {
            return tex;
        }

        return {};
    }

    // True when the candidate (extension stripped) ends with the full segment sequence of the wanted path
    bool ends_with_path(const fs::path& candidate, const std::string& wanted) {
        fs::path stripped = candidate;
        stripped.replace_extension();

        const std::string path = normalize_path(stripped.string());
        if (path.size() < wanted.size()) {
            return false;
        }

        const size_t start = path.size() - wanted.size();
        if (path.compare(start, wanted.size(), wanted) != 0) {
            return false;
        }

        return start == 0 || path[start - 1] == '\\';
    }

    // Last resort index, built at most once per ARCFS directory
    fs::path g_index_root;
    std::vector<fs::path> g_index;
    bool g_index_built = false;

    void build_texture_index(const fs::path& root) {
        g_index.clear();

        std::error_code ec;
        for (const auto& entry : fs::recursive_directory_iterator(root, fs::directory_options::skip_permission_denied, ec)) {
            if (ec || !entry.is_regular_file(ec)) {
                continue;
            }

            if (has_extension(entry.path(), ".dds") || has_extension(entry.path(), ".tex")) {
                g_index.push_back(entry.path());
            }
        }

        g_index_root = root;
        g_index_built = true;
        spdlog::info("Indexed {} textures under {}", g_index.size(), root.string());
    }

    fs::path find_texture_by_suffix(const fs::path& root, const std::string& texture_path) {
        if (!g_index_built || g_index_root != root) {
            build_texture_index(root);
        }

        const std::string wanted = normalize_path(texture_path);
        fs::path tex_match;

        for (const auto& candidate : g_index) {
            if (!ends_with_path(candidate, wanted)) {
                continue;
            }

            if (has_extension(candidate, ".dds")) {
                return candidate;
            }

            if (tex_match.empty()) {
                tex_match = candidate;
            }
        }

        return tex_match;
    }

    // A MHXR texture path is relative to a screen directory that the .gui file does not store,
    // so the file has to be searched for rather than simply concatenated:
    //   1. <arcfs>/<path>                arcfs already points at the screen directory
    //   2. <arcfs>/<screen>/<path>       normal layout, one level of directories to try
    //   3. suffix match over a full scan anything else
    fs::path resolve_texture(const fs::path& root, const std::string& texture_path) {
        if (auto found = probe_texture(root, texture_path); !found.empty()) {
            return found;
        }

        std::error_code ec;
        for (const auto& entry : fs::directory_iterator(root, fs::directory_options::skip_permission_denied, ec)) {
            if (ec || !entry.is_directory(ec)) {
                continue;
            }

            if (auto found = probe_texture(entry.path(), texture_path); !found.empty()) {
                return found;
            }
        }

        return find_texture_by_suffix(root, texture_path);
    }
}

void GUIFile::load_resources(const std::string& chunk_path, const std::string& native_path, const std::string& arcfs_path, ID3D11Device* device, ID3D11DeviceContext* context) {
    if (get_version() == Version::MHW) {
        for (auto& texture : m_textures) {
            const char* extension = texture.Meta.RenderTargetType == 1 ? ".rtex" : ".tex";

            const std::filesystem::path chunk = std::filesystem::path(chunk_path) / (texture.Path + extension);
            const std::filesystem::path native = std::filesystem::path(native_path) / (texture.Path + extension);
            std::filesystem::path path;

            if (exists(native)) {
                path = native;
            } else if (exists(chunk)) {
                path = chunk;
            } else {
                spdlog::error("Could not find texture: {}", texture.Path);
                continue;
            }

            try {
                BinaryReader stream(path);
                texture.RenderTexture.load_from(stream, false, device, context);
            }
            catch (...) {
                spdlog::error("Could not load texture: {}", texture.Path);
            }
        }
    }

    if (get_version() == Version::MHGU) {
        for (auto& texture : m_textures) {
            const char* extension = texture.Meta.RenderTargetType == 1 ? ".rtex" : ".tex";
            const std::filesystem::path path = std::filesystem::path(arcfs_path) / (texture.Path + extension);

            if (!exists(path)) {
                spdlog::error("Could not find texture: {}", texture.Path);
                continue;
            }

            try {
                BinaryReader stream(path);
                texture.RenderTexture.load_from(stream, true, device, context);
            }
            catch (...) {
                spdlog::error("Could not load texture: {}", texture.Path);
            }
        }
    }

    if (get_version() == Version::MHXR) {
        for (auto& texture : m_textures) {
            texture.ErrorCode = TextureLoadError::None;
            texture.ErrorParam.clear();

            if (arcfs_path.empty()) {
                texture.ErrorCode = TextureLoadError::ArcfsNotSet;
                spdlog::error("ARCFS path not set, cannot load texture: {}", texture.Path);
                continue;
            }

            if (texture.Path.empty()) {
                texture.ErrorCode = TextureLoadError::EmptyPath;
                spdlog::error("Texture {} has no path", texture.ID);
                continue;
            }

            const std::filesystem::path root = arcfs_path;
            const auto found = resolve_texture(root, texture.Path);

            std::filesystem::path dds_path;
            std::filesystem::path tex_path;

            if (!found.empty()) {
                if (has_extension(found, ".dds")) {
                    dds_path = found;
                } else {
                    tex_path = found;
                }

                texture.ResolvedPath = found.string();
            }

            if (dds_path.empty()) {
                if (exists(tex_path)) {
                    // The source texture is there, it just has not been converted yet
                    texture.ErrorCode = TextureLoadError::DdsMissing;
                    texture.ErrorParam = tex_path.string();
                    spdlog::warn("DDS missing, TEX present: {}", tex_path.string());
                } else {
                    const std::string wanted = (root / texture.Path).string();
                    texture.ErrorCode = TextureLoadError::NotFound;
                    texture.ErrorParam = wanted;
                    spdlog::error("Could not find texture (dds and tex): {}", wanted);
                    texture.ResolvedPath = wanted;
                }

                continue;
            }

            try {
                if (!texture.RenderTexture.load_dds_from_file(dds_path, device, context)) {
                    texture.ErrorCode = TextureLoadError::DecodeFailed;
                    texture.ErrorParam = dds_path.string();
                    spdlog::error("Could not load dds texture: {}", dds_path.string());
                }
            }
            catch (const std::exception& e) {
                texture.ErrorCode = TextureLoadError::DecodeException;
                texture.ErrorParam = fmt::format("{} -> {}", e.what(), dds_path.string());
                spdlog::error("Exception while loading dds texture {}: {}", dds_path.string(), e.what());
            }
            catch (...) {
                texture.ErrorCode = TextureLoadError::DecodeUnknown;
                texture.ErrorParam = dds_path.string();
                spdlog::error("Unknown exception while loading dds texture: {}", dds_path.string());
            }
        }
    }

    // TODO: load other kinds of resources
}

void GUIFile::run_data_usage_analysis(bool log_overlapping_offsets) const {
#ifdef GUI_FILE_ANALYSIS
    spdlog::info("Analyzing GUIFile...");

    std::unordered_map<KeyValueType, std::unordered_map<u32, u32>> p_offsets;
    std::unordered_map<KeyValueType, std::unordered_map<u32, u32>> ip_offsets;

    for (const auto& param : m_params) {
        if (param.ValueCount > 0 && param.ValueOffsetType != KeyValueType::None) {
            p_offsets[param.ValueOffsetType][param.OrgValueOffset] += 1;
        }
    }

    std::unordered_map<u32, u32> ip_val_offsets;
    for (const auto& param : m_init_params) {
        if (param.ValueOffsetType != KeyValueType::None) {
            ip_offsets[param.ValueOffsetType][param.OrgValueOffset] += 1;
        }
    }

    for (auto i = static_cast<u32>(KeyValueType::KV8); i < static_cast<u32>(KeyValueType::String); ++i) {
        const auto kvt = static_cast<KeyValueType>(i);

        const std::unordered_map<u32, u32>& param_data = p_offsets[kvt];
        const std::unordered_map<u32, u32>& iparam_data = ip_offsets[kvt];

        const auto p_keys = param_data | std::views::keys;
        const auto p_values = param_data | std::views::values;
        const auto ip_keys = iparam_data | std::views::keys;
        const auto ip_values = iparam_data | std::views::values;

        const ptrdiff_t p_overlaps = std::ranges::count_if(p_values, [](u32 v) { return v > 0; });
        const ptrdiff_t ip_overlaps = std::ranges::count_if(ip_values, [](u32 v) {return v > 0; });
        const u32 p_max_overlap = p_values.size() > 0 ? *std::ranges::max_element(p_values) : 0;
        const u32 ip_max_overlap = ip_values.size() > 0 ? *std::ranges::max_element(ip_values) : 0;

        std::vector<u32> overlapping_offsets{};
        std::ranges::set_intersection(p_keys, ip_keys, std::back_inserter(overlapping_offsets));

        spdlog::info("[Param] {} total overlapping {} Offsets. (Highest: {})", p_overlaps, enum_to_string(kvt), p_max_overlap);
        spdlog::info("[InitParam] {} total overlapping {} Offsets. (Highest: {})", ip_overlaps, enum_to_string(kvt), ip_max_overlap);
        spdlog::info("[Param & InitParam] share {} common {} offsets", overlapping_offsets.size(), enum_to_string(kvt));

        if (log_overlapping_offsets) {
            for (const u32 offset : overlapping_offsets) {
                spdlog::info("{:08X}", offset);
            }

            const auto more_than_1 = [](const auto& p) { return std::get<1>(p) > 1; };

            spdlog::info("[Param] The following {} offsets are used multiple times:", enum_to_string(kvt));
            for (const auto& [offset, count] : param_data | std::views::filter(more_than_1)) {
                spdlog::info("{:08X}: {} times", offset, count);
            }

            spdlog::info("[InitParam] The following {} offsets are used multiple times:", enum_to_string(kvt));
            for (const auto& [offset, count] : iparam_data | std::views::filter(more_than_1)) {
                spdlog::info("{:08X}: {} times", offset, count);
            }
        }
    }


    for (auto i = 0u; i < m_init_params.size(); ++i) {
        u32 obj_use_count = 0;
        u32 inst_use_count = 0;
        u32 objseq_use_count = 0;

        for (const auto& obj : m_objects) {
            const u32 start = obj.InitParamIndex;
            const u32 end = start + obj.InitParamNum;

            if (i <= start && i < end) {
                ++obj_use_count;
            }
        }

        for (const auto& inst : m_instances) {
            const u32 start = inst.InitParamIndex;
            const u32 end = start + inst.InitParamNum;

            if (i <= start && i < end) {
                ++inst_use_count;
            }
        }

        for (const auto& objseq : m_obj_sequences) {
            const u32 start = objseq.InitParamIndex;
            const u32 end = start + objseq.InitParamNum;

            if (i <= start && i < end) {
                ++objseq_use_count;
            }
        }

        spdlog::info("InitParam[{}] used by {} Objects, {} Instances, and {} ObjSequences", i, obj_use_count, inst_use_count, objseq_use_count);
    }


#else
    spdlog::info("GUIFile Analysis disabled. Skipping analysis.");
#endif
}

bool GUIFile::save_to(BinaryWriter& stream, const Settings& settings) const {
    StringBuffer string_buffer;
    KeyValueBuffers kv_buffers{
        .Config = {
            .MultipleKV8Refs = settings.AllowMultipleKV8References,
            .MultipleKV32Refs = settings.AllowMultipleKV32References,
            .MultipleKV128Refs = settings.AllowMultipleKV128References,
        }
    };

    if (get_version() == Version::MHXR) {
        // Patch based saving: copy the original file byte for byte and only overwrite what
        // actually changed (currently the header). Nothing changed -> byte identical output.
        if (m_original.empty()) {
            spdlog::error("Cannot save: original file bytes are unavailable");
            return false;
        }

        // Adding or removing entries cannot be expressed as a patch yet -> refuse instead of
        // silently dropping the change.
        const bool counts_changed =
            m_animations.size() != m_header.animationNum ||
            m_sequences.size() != m_header.sequenceNum ||
            m_objects.size() != m_header.objectNum ||
            m_obj_sequences.size() != m_header.objSequenceNum ||
            m_init_params.size() != m_header.initParamNum ||
            m_params.size() != m_header.paramNum ||
            m_keys.size() != m_header.keyNum ||
            m_instances.size() != m_header.instanceNum ||
            m_flows.size() != m_header.flowNum ||
            m_flow_processes.size() != m_header.flowProcessNum ||
            m_textures.size() != m_header.textureNum ||
            m_fonts.size() != m_header.fontNum ||
            m_font_filters.size() != m_header.fontFilterNum ||
            m_messages.size() != m_header.messageNum ||
            m_resources.size() != m_header.guiResourceNum ||
            m_general_resources.size() != m_header.generalResourceNum;

        if (counts_changed) {
            spdlog::error("Saving structural changes (added or removed entries) is not supported yet.");
            return false;
        }

        stream.write(std::span<const u8>(m_original));

        GUIHeader header = m_header;
        header.fileSize = static_cast<u32>(m_original.size());

        stream.seek_absolute(0);
        stream.write(header);

        // Disabled for now: the parameter diff reports false positives (bytes differ even when
        // nothing was edited), which would corrupt the file. Needs one more debugging round.
        // diff_param_values();

        // Apply every recorded field edit on top of the original bytes
        for (const auto& change : m_changes) {
            stream.seek_absolute(static_cast<s64>(change.Offset));
            stream.write(std::span<const u8>(change.Bytes));
        }
    } else if (get_version() == Version::MHW) {
        GUIHeader header = {
            .fileType = {'G', 'U', 'I', '\0'},
            .guiVersion = m_version,
            .fileSize = 0,
            .attr = m_attr,
            .revisionDate = std::time(nullptr),
            .instanceID = m_instance_id,
            .flowID = m_flow_id,
            .variableID = m_variable_id,
            .startInstanceIndex = m_start_instance_index,
            .animationNum = static_cast<u32>(m_animations.size()),
            .sequenceNum = static_cast<u32>(m_sequences.size()),
            .objectNum = static_cast<u32>(m_objects.size()),
            .objSequenceNum = static_cast<u32>(m_obj_sequences.size()),
            .initParamNum = static_cast<u32>(m_init_params.size()),
            .paramNum = static_cast<u32>(m_params.size()),
            .keyNum = static_cast<u32>(m_keys.size()),
            .instanceNum = static_cast<u32>(m_instances.size()),
            .flowNum = static_cast<u32>(m_flows.size()),
            .flowProcessNum = static_cast<u32>(m_flow_processes.size()),
            .flowInputNum = 0,
            .flowSwitchNum = 0,
            .flowFunctionNum = 0,
            .actionNum = 0,
            .inputConditionNum = 0,
            .switchConditionNum = 0,
            .switchOperatorNum = 0,
            .variableNum = 0,
            .textureNum = static_cast<u32>(m_textures.size()),
            .fontNum = 0,
            .fontFilterNum = static_cast<u32>(m_font_filters.size()),
            .messageNum = static_cast<u32>(m_messages.size()),
            .guiResourceNum = static_cast<u32>(m_resources.size()),
            .generalResourceNum = static_cast<u32>(m_general_resources.size()),
            .cameraSettingNum = 0,
            .instExeParamNum = static_cast<u32>(m_instances.size()),
            .vertexBufferSize = 0,
            .optionBitFlag = m_header.optionBitFlag,
            .viewSize_Width = m_header.viewSize_Width,
            .viewSize_Height = m_header.viewSize_Height,
            .startFlowIndex = m_header.startFlowIndex,
            .instanceParamEntryStartIndex = m_header.instanceParamEntryStartIndex
            // Rest of the fields will be filled later
        };

        stream.write(header);

        header.animationOffset = stream.tell();
        for (const auto& animation : m_animations) {
            animation.write(stream, string_buffer);
        }

        header.sequenceOffset = stream.tell();
        for (const auto& sequence : m_sequences) {
            sequence.write(stream, string_buffer);
        }

        header.objectOffset = stream.tell();
        for (const auto& object : m_objects) {
            object.write(stream, string_buffer, kv_buffers);
        }

        if (m_objects.size() % 2) {
            // On odd number of objects, there are 8 bytes of padding
            // Not technically necessary, just for alignment purposes
            stream.write<u64>(0);
        }

        header.objSequenceOffset = stream.tell();
        for (const auto& obj_sequence : m_obj_sequences) {
            obj_sequence.write(stream, string_buffer);
        }

        if (m_obj_sequences.size() % 2) {
            // Same thing here
            stream.write<u64>(0);
        }

        header.initParamOffset = stream.tell();
        for (const auto& init_param : m_init_params) {
            init_param.write(stream, string_buffer, kv_buffers);
        }

        header.paramOffset = stream.tell();
        for (const auto& param : m_params) {
            param.write(stream, string_buffer, kv_buffers);
        }

        header.instanceOffset = stream.tell();
        for (const auto& instance : m_instances) {
            instance.write(stream, string_buffer, kv_buffers);
        }

        if (m_instances.size() % 2) {
            stream.write<u64>(0);
        }

        header.flowOffset = stream.tell();
        for (const auto& flow : m_flows) {
            flow.write(stream, string_buffer);
        }

        header.flowProcessOffset = stream.tell();
        for (const auto& flow_process : m_flow_processes) {
            flow_process.write(stream, string_buffer);
        }

        header.textureOffset = stream.tell();
        for (const auto& texture : m_textures) {
            texture.write(stream, string_buffer);
        }

        header.fontFilterOffset = stream.tell();
        for (const auto& font_filter : m_font_filters) {
            font_filter->write(stream, string_buffer);
        }

        // Align to 16 bytes
        auto n_align = ((16 - stream.tell() % 16) / 4) % 4; // All font filters have a multiple of 4 size
        for (auto i = 0u; i < n_align; ++i) {
            stream.write<u32>(0);
        }

        header.messageOffset = stream.tell();
        for (const auto& message : m_messages) {
            message.write(stream, string_buffer);
        }

        if (m_messages.size() % 2) {
            stream.write<u64>(0);
        }

        header.guiResourceOffset = stream.tell();
        for (const auto& resource : m_resources) {
            resource.write(stream, string_buffer);
        }

        if (m_resources.size() % 2) {
            stream.write<u64>(0);
        }

        header.generalResourceOffset = stream.tell();
        for (const auto& general_resource : m_general_resources) {
            general_resource.write(stream, string_buffer);
        }

        if (m_general_resources.size() % 2) {
            stream.write<u64>(0);
        }

        header.keyOffset = stream.tell();
        for (const auto& key : m_keys) {
            key.write(stream, string_buffer, kv_buffers);
        }

        header.keyValue8Offset = stream.tell();
        stream.write(std::span<const u8>(kv_buffers.KeyValue8));

        n_align = 16 - stream.tell() % 16;
        for (auto i = 0u; i < n_align; ++i) {
            stream.write<u8>(0);
        }

        header.keyValue32Offset = stream.tell();
        stream.write(std::span<const u32>(kv_buffers.KeyValue32));

        n_align = ((16 - stream.tell() % 16) / 4) % 4;
        for (auto i = 0u; i < n_align; ++i) {
            stream.write<u32>(0);
        }

        header.keyValue128Offset = stream.tell();
        stream.write(std::span<const vector4>(kv_buffers.KeyValue128));

        header.extendDataOffset = stream.tell();
        stream.write(std::span<const u8>(kv_buffers.ExtendData));

        n_align = 16 - stream.tell() % 16;
        for (auto i = 0u; i < n_align; ++i) {
            stream.write<u8>(0);
        }

        header.stringOffset = stream.tell();
        stream.write(string_buffer.data(), string_buffer.size());

        n_align = 16 - stream.tell() % 16;
        for (auto i = 0u; i < n_align; ++i) {
            stream.write<u8>(0);
        }

        header.vertexOffset = stream.tell();
        header.vertexBufferSize = static_cast<u32>(m_vertices.size() * GUIVertex::size);
        for (const auto& vertex : m_vertices) {
            vertex.write(stream, string_buffer);
        }

        header.fileSize = static_cast<u32>(stream.tell());

        stream.seek_absolute(0);
        stream.write(header);
    } else if (get_version() == Version::MHGU) {
        GUIHeaderMHGU header = {
            .fileType = {'G', 'U', 'I', '\0'},
            .guiVersion = m_version,
            .fileSize = 0,
            .attr = m_attr,
            .revisionDate = std::time(nullptr),
            .instanceID = m_instance_id,
            .flowID = m_flow_id,
            .variableID = m_variable_id,
            .startInstanceIndex = m_start_instance_index,
            .animationNum = static_cast<u32>(m_animations.size()),
            .sequenceNum = static_cast<u32>(m_sequences.size()),
            .objectNum = static_cast<u32>(m_objects.size()),
            .objSequenceNum = static_cast<u32>(m_obj_sequences.size()),
            .initParamNum = static_cast<u32>(m_init_params.size()),
            .paramNum = static_cast<u32>(m_params.size()),
            .keyNum = static_cast<u32>(m_keys.size()),
            .instanceNum = static_cast<u32>(m_instances.size()),
            .flowNum = static_cast<u32>(m_flows.size()),
            .flowProcessNum = static_cast<u32>(m_flow_processes.size()),
            .flowInputNum = 0,
            .flowSwitchNum = 0,
            .flowFunctionNum = 0,
            .actionNum = 0,
            .inputConditionNum = 0,
            .switchConditionNum = 0,
            .switchOperatorNum = 0,
            .variableNum = 0,
            .textureNum = static_cast<u32>(m_textures.size()),
            .fontNum = 0,
            .fontFilterNum = static_cast<u32>(m_font_filters.size()),
            .messageNum = static_cast<u32>(m_messages.size()),
            .guiResourceNum = static_cast<u32>(m_resources.size()),
            .generalResourceNum = static_cast<u32>(m_general_resources.size()),
            .cameraSettingNum = 0,
            .instExeParamNum = static_cast<u32>(m_instances.size()),
            .vertexBufferSize = 0,
            .optionBitFlag = m_header_mhgu.optionBitFlag,
            .viewSize_Width = m_header_mhgu.viewSize_Width,
            .viewSize_Height = m_header_mhgu.viewSize_Height,
            .startFlowIndex = m_header_mhgu.startFlowIndex,
            .instExeParamOffset = m_header_mhgu.instExeParamOffset
            // Rest of the fields will be filled later
        };

        stream.write(header);
        stream.pad_to(16);

        header.animationOffset = stream.tell32();
        for (const auto& animation : m_animations) {
            animation.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.sequenceOffset = stream.tell32();
        for (const auto& sequence : m_sequences) {
            sequence.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.objectOffset = stream.tell32();
        for (const auto& object : m_objects) {
            object.write_mhgu(stream, string_buffer, kv_buffers);
        }

        stream.pad_to(16);

        header.objSequenceOffset = stream.tell32();
        for (const auto& obj_sequence : m_obj_sequences) {
            obj_sequence.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.initParamOffset = stream.tell32();
        for (const auto& init_param : m_init_params) {
            init_param.write_mhgu(stream, string_buffer, kv_buffers);
        }

        stream.pad_to(16);

        header.paramOffset = stream.tell32();
        for (const auto& param : m_params) {
            param.write_mhgu(stream, string_buffer, kv_buffers);
        }

        stream.pad_to(16);

        header.instanceOffset = stream.tell32();
        for (const auto& instance : m_instances) {
            instance.write_mhgu(stream, string_buffer, kv_buffers);
        }

        stream.pad_to(16);

        header.flowOffset = stream.tell32();
        for (const auto& flow : m_flows) {
            flow.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.flowProcessOffset = stream.tell32();
        for (const auto& flow_process : m_flow_processes) {
            flow_process.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.textureOffset = stream.tell32();
        for (const auto& texture : m_textures) {
            texture.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.fontFilterOffset = stream.tell32();
        for (const auto& font_filter : m_font_filters) {
            font_filter->write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.messageOffset = stream.tell32();
        for (const auto& message : m_messages) {
            message.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.guiResourceOffset = stream.tell32();
        for (const auto& resource : m_resources) {
            resource.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.generalResourceOffset = stream.tell32();
        for (const auto& general_resource : m_general_resources) {
            general_resource.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);

        header.keyOffset = stream.tell32();
        for (const auto& key : m_keys) {
            key.write_mhgu(stream, string_buffer, kv_buffers);
        }

        header.keyValue8Offset = stream.tell32();
        stream.write(std::span<const u8>(kv_buffers.KeyValue8));

        stream.pad_to(16);

        header.keyValue32Offset = stream.tell32();
        stream.write(std::span<const u32>(kv_buffers.KeyValue32));

        stream.pad_to(16);

        header.keyValue128Offset = stream.tell32();
        stream.write(std::span<const vector4>(kv_buffers.KeyValue128));

        header.extendDataOffset = stream.tell32();
        stream.write(std::span<const u8>(kv_buffers.ExtendData));

        stream.pad_to(16);

        header.stringOffset = stream.tell32();
        stream.write(string_buffer.data(), string_buffer.size());

        stream.pad_to(16);

        header.vertexOffset = stream.tell32();
        header.vertexBufferSize = static_cast<u32>(m_vertices.size() * GUIVertex::size);
        for (const auto& vertex : m_vertices) {
            vertex.write_mhgu(stream, string_buffer);
        }

        stream.pad_to(16);
        header.fileSize = static_cast<u32>(stream.tell());

        stream.seek_absolute(0);
        stream.write(header);
    } else {
        spdlog::error("Cannot save: unknown gui version {:#x}", static_cast<u32>(m_header.guiVersion));
        return false;
    }

    return true;
}

void GUIFile::insert_animation(GUIAnimation anim, s32 index, bool) {
    if (index < 0) {
        m_animations.emplace_back(std::move(anim));
        return;
    }

    m_animations.emplace(m_animations.begin() + index, std::move(anim));
}

void GUIFile::insert_sequence(GUISequence seq, s32 index, bool update_indices) {
    if (index < 0) {
        m_sequences.emplace_back(std::move(seq));
        return;
    }

    m_sequences.emplace(m_sequences.begin() + index, std::move(seq));

    if (update_indices) {
        for (auto& anim : m_animations) {
            if (anim.SequenceIndex >= index) {
                ++anim.SequenceIndex;
            }
        }
    }
}

void GUIFile::insert_object(GUIObject obj, s32 index, bool update_indices) {
    if (index < 0) {
        m_objects.emplace_back(std::move(obj));
        return;
    }

    m_objects.emplace(m_objects.begin() + index, std::move(obj));

    if (update_indices) {
        for (auto& anim : m_animations) {
            if (anim.RootObjectIndex >= index) {
                ++anim.RootObjectIndex;
            }
        }
    }
}

void GUIFile::insert_object_sequence(GUIObjectSequence objseq, s32 index, bool update_indices) {
    if (index < 0) {
        m_obj_sequences.emplace_back(objseq);
        return;
    }

    m_obj_sequences.emplace(m_obj_sequences.begin() + index, objseq);

    if (update_indices) {
        for (auto& obj : m_objects) {
            if (obj.ObjectSequenceIndex >= index) {
                ++obj.ObjectSequenceIndex;
            }
        }
    }
}

void GUIFile::insert_init_param(GUIInitParam param, s32 index, bool update_indices) {
    if (index < 0) {
        m_init_params.emplace_back(std::move(param));
        return;
    }

    m_init_params.emplace(m_init_params.begin() + index, std::move(param));

    if (update_indices) {
        // Objects, Instances, ObjectSequences
        auto update_init_param_indices = [&](auto& container) {
            for (auto& obj : container) {
                if (obj.InitParamIndex >= index) {
                    ++obj.InitParamIndex;
                }
            }
        };

        update_init_param_indices(m_objects);
        update_init_param_indices(m_instances);
        update_init_param_indices(m_obj_sequences);
    }
}

void GUIFile::insert_param(GUIParam param, s32 index, bool update_indices) {
    if (index < 0) {
        m_params.emplace_back(std::move(param));
        return;
    }

    m_params.emplace(m_params.begin() + index, std::move(param));

    if (update_indices) {
        for (auto& objseq : m_obj_sequences) {
            if (objseq.ParamIndex >= index) {
                ++objseq.ParamIndex;
            }
        }
    }
}

void GUIFile::insert_key(GUIKey key, s32 index, bool update_indices) {
    if (index < 0) {
        m_keys.emplace_back(key);
        return;
    }

    m_keys.emplace(m_keys.begin() + index, key);

    if (update_indices) {
        for (auto& param : m_params) {
            if (param.KeyIndex >= index) {
                ++param.KeyIndex;
            }
        }
    }
}

void GUIFile::insert_instance(GUIInstance inst, s32 index, bool update_indices) {
    if (index < 0) {
        m_instances.emplace_back(std::move(inst));
        return;
    }

    m_instances.emplace(m_instances.begin() + index, std::move(inst));

    if (update_indices) {
        if (m_start_instance_index >= index) {
            ++m_start_instance_index;
        }
    }
}

void GUIFile::insert_flow(GUIFlow flow, s32 index, bool update_indices) {
    if (index < 0) {
        m_flows.emplace_back(std::move(flow));
        return;
    }

    m_flows.emplace(m_flows.begin() + index, std::move(flow));

    if (update_indices) {
        if (m_header.startFlowIndex >= index) {
            ++m_header.startFlowIndex;
        }

        for (auto& _flow : m_flows) {
            if (_flow.Type == FlowType::START && _flow.FlowProcessIndex >= index) {
                ++_flow.FlowProcessIndex;
            }
        }

        for (auto& fp : m_flow_processes) {
            if (fp.FlowIndex >= index) {
                ++fp.FlowIndex;
            }
        }
    }
}

void GUIFile::insert_flow_process(GUIFlowProcess flow, s32 index, bool update_indices) {
    if (index < 0) {
        m_flow_processes.emplace_back(std::move(flow));
        return;
    }

    m_flow_processes.emplace(m_flow_processes.begin() + index, std::move(flow));

    if (update_indices) {
        for (auto& _flow : m_flows) {
            if (_flow.Type == FlowType::PROCESS && _flow.FlowProcessIndex >= index) {
                ++_flow.FlowProcessIndex;
            }
        }
    }
}

void GUIFile::insert_texture(GUITexture tex, s32 index, bool) {
    if (index < 0) {
        m_textures.emplace_back(std::move(tex));
        return;
    }

    m_textures.emplace(m_textures.begin() + index, std::move(tex));
}

void GUIFile::insert_font_filter(std::shared_ptr<GUIFontFilter> filter, s32 index, bool) {
    if (index < 0) {
        m_font_filters.emplace_back(std::move(filter));
        return;
    }

    m_font_filters.emplace(m_font_filters.begin() + index, std::move(filter));
}

void GUIFile::erase_keys(u32 index, u32 count, bool update_indices) {
    if (index >= m_keys.size() || count == 0) {
        return;
    }

    m_keys.erase(m_keys.begin() + index, m_keys.begin() + index + count);

    if (!update_indices) {
        return;
    }

    for (auto& param : m_params) {
        if (param.KeyIndex >= index) {
            param.KeyIndex -= count;
        }
    }
}

u32 GUIFile::get_animation_object_count(u32 anim_index) const {
    return 0;
}
