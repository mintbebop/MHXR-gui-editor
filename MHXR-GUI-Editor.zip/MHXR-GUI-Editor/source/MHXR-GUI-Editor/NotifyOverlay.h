#pragma once

// Self-drawn notification overlay: drawn on the ImGui foreground draw list so it is
// ALWAYS visible (the imgui-notify toasts were not reliably visible in this app).

#include "pch.h"

#include <deque>
#include <string>

namespace OverlayNotify {
    struct Message {
        std::string Text;
        float Life = 4.0f;
    };

    inline std::deque<Message> Messages;

    inline void push(std::string text) {
        Messages.push_back({ std::move(text), 4.0f });

        while (Messages.size() > 6) {
            Messages.pop_front();
        }
    }

    inline void render() {
        if (Messages.empty()) {
            return;
        }

        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        const ImVec2 display = ImGui::GetIO().DisplaySize;

        float y = 70.0f;

        for (auto& message : Messages) {
            message.Life -= ImGui::GetIO().DeltaTime;

            const ImVec2 size = ImGui::CalcTextSize(message.Text.c_str());
            const float x = (display.x - size.x) * 0.5f;

            draw_list->AddRectFilled(
                ImVec2(x - 12.0f, y - 7.0f),
                ImVec2(x + size.x + 12.0f, y + size.y + 7.0f),
                IM_COL32(18, 18, 22, 215), 4.0f);
            draw_list->AddRect(
                ImVec2(x - 12.0f, y - 7.0f),
                ImVec2(x + size.x + 12.0f, y + size.y + 7.0f),
                IM_COL32(120, 180, 170, 255), 4.0f);
            draw_list->AddText(ImVec2(x, y), IM_COL32(240, 240, 240, 255), message.Text.c_str());

            y += size.y + 18.0f;
        }

        while (!Messages.empty() && Messages.front().Life <= 0.0f) {
            Messages.pop_front();
        }
    }
}
