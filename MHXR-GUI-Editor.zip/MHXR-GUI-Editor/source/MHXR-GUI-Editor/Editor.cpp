#include "pch.h"
#include "App.h"
#include "Editor.h"
#include "HrException.h"
#include "IconFontAwesome.h"
#include "BinaryReader.h"
#include "BinaryWriter.h"
#include "GUIEditor.h"
#include "GUIFile.h"
#include "GroupPanel.h"
#include "I18n.h"
#include "version_info.h"

#include "imgui-notify/imgui_notify.h"
#include "imgui-notify/tahoma.h"

#include <fmt/format.h>
#include <imgui_internal.h>
#include <imgui_stdlib.h>
#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <ShObjIdl.h>
#include <spdlog/spdlog.h>
#include <wrl.h>
#include <nlohmann/json.hpp>

#include <fstream>
#include <optional>
#include <ranges>



Editor::Editor(App* owner) : m_owner(owner) {
    HR_INIT(S_OK);
    HR_ASSERT(CoInitializeEx(nullptr, COINIT_MULTITHREADED));

    // Load settings (incl. UI language) before anything looks up a translation
    m_settings.load();
    I18n::init(m_settings.Language);
    g_ui_language = m_settings.Language;

    add_menu_item("menu.file", { ICON_FA_FILE, "menu.file.open", "Ctrl+O", [](Editor* e) { e->open_file(); } });
    add_menu_item("menu.file", { ICON_FA_FLOPPY_DISK, "menu.file.save", "Ctrl+S", [](Editor* e) { e->save_file(); } });
    add_menu_item("menu.file", { nullptr, "menu.file.save_as", "Ctrl+Shift+S", [](Editor* e) { e->save_file_as(); } });
    // Disabled: there is no animation editor window yet
    add_menu_item("menu.view", { ICON_FA_FILM, "menu.view.animation_editor", nullptr, [this](Editor* e) {

    }, false });

    // Disabled: the preview only draws a single static frame
    add_menu_item("menu.view", { ICON_FA_EXPAND, "menu.view.preview", nullptr, [this](Editor* e) {
        m_preview_open = true;
    }, false });

    // Disabled: needs EditorPath parsing and an object editor to jump to
    add_menu_item("menu.edit", { ICON_FA_ARROW_RIGHT, "menu.edit.go_to", nullptr, [](Editor* e) {
        //e->m_generic_popup_queue.emplace("Go To...", [e](std::any& data) {
        //    auto& path = std::any_cast<std::string&>(data);
        //    if (ImGui::InputText("Path", &path)) {
        //        //data = path;
        //    }

        //    ImGui::NewLine();

        //    if (ImGui::Button("Go")) {
        //        ImGui::CloseCurrentPopup();
        //        //e->m_selected_object = e->m_file.find_object(path);
        //        return true;
        //    }

        //    if (ImGui::Button("Cancel")) {
        //        ImGui::CloseCurrentPopup();
        //        return true;
        //    }

        //    return false;
        //}, std::string{});
    }, false });

    m_settings.load();
    m_theme_manager.set_theme_directory("./themes");
    m_theme_manager.refresh();

    m_theme_manager.apply_style(m_settings.Theme.empty() ? "Default" : m_settings.Theme);

    // Everything the UI itself can show, loaded before the first atlas build
    collect_static_glyphs();
    m_glyphs_dirty = false;

    // Runs before ImGui_ImplDX11_Init, so the device texture is built on the first frame
    load_fonts(false);

    capture_base_style();
    apply_ui_scale();

    nlohmann::json object_info;

    try {
        std::ifstream("./data/cGUIObject.json") >> object_info;
    }
    catch (const std::exception& e) {
        spdlog::error("Failed to load cGUIObject.json: {}", e.what());
    }

    for (const auto& [key, value] : object_info.items()) {
        ObjectInfo info{};
        info.Name = key;
        info.Type = ObjectTypeNamesReversed.at(info.Name);

        for (const auto& field : value["Fields"]) {
            info.Params[field.value("Name", "N/A")] = static_cast<ParamType>(field.value("Type", 0));
        }

        const auto p_info = std::make_shared<ObjectInfo>(std::move(info));
        m_object_info[key] = p_info;
        m_object_info2[p_info->Type] = p_info;
    }

    m_owner->add_window_message_callback([this](UINT msg, WPARAM wparam, LPARAM lparam) {
        if (msg == WM_DROPFILES) {
            handle_file_drop((HDROP)wparam);
        }
    });
}

void Editor::add_menu_item(const std::string& menu_key, const MenuItem& item) {
    for (auto& m : m_menu_items) {
        if (m.NameKey == menu_key) {
            m.Items.push_back(item);
            return;
        }
    }

    m_menu_items.emplace_back(menu_key, std::vector{ item });
}

void Editor::add_popup(const std::string& title, const std::string& message, PopupType type, const YesNoCancelPopup::CallbackType& callback, std::any user_data) {
    m_popup_queue.emplace(title, message, type, callback, user_data);
}

void Editor::render(u32 dockspace_id) {
    rebuild_fonts_if_needed();

    // Rebuild whenever the layout version changes, so a missing or stale imgui.ini
    // can never leave the editor without panes. Manual adjustments are kept otherwise.
    if (m_settings.LayoutVersion != CURRENT_LAYOUT_VERSION) {
        m_dock_built = true;

        //   right: Header | center: Tree Viewer | bottom-left: Resource Manager | bottom-right: Texture Viewer
        const ImGuiID root_id = dockspace_id;
        ImGuiID center_id = root_id;

        ImGui::DockBuilderRemoveNode(root_id);
        ImGui::DockBuilderAddNode(root_id, ImGuiDockNodeFlags_DockSpace);
        ImGui::DockBuilderSetNodeSize(root_id, ImGui::GetMainViewport()->Size);

        //   left: Tree Viewer | right: Header | center-top: Texture Viewer | center-bottom: Resource Manager
        const ImGuiID dock_id_left = ImGui::DockBuilderSplitNode(center_id, ImGuiDir_Left, 0.22f, nullptr, &center_id);
        const ImGuiID dock_id_right = ImGui::DockBuilderSplitNode(center_id, ImGuiDir_Right, 0.25f, nullptr, &center_id);
        const ImGuiID dock_id_center_bottom = ImGui::DockBuilderSplitNode(center_id, ImGuiDir_Down, 0.55f, nullptr, &center_id);

        ImGui::DockBuilderDockWindow(I18n::T("window.tree_viewer"), dock_id_left);
        ImGui::DockBuilderDockWindow(I18n::T("window.header"), dock_id_right);
        ImGui::DockBuilderDockWindow(I18n::T("window.texture_viewer"), center_id);
        ImGui::DockBuilderDockWindow(I18n::T("window.resource_manager"), dock_id_center_bottom);
        ImGui::DockBuilderFinish(root_id);

        m_settings.LayoutVersion = CURRENT_LAYOUT_VERSION;
        m_settings.save();
    }

    if (m_first_render) {
        m_first_render = false;

        // Create samplers
        const auto device = m_owner->get_device().Get();
        m_samplers[SamplerMode::WrapLinear] = std::make_unique<Sampler>(device, SamplerMode::WrapLinear);
        m_samplers[SamplerMode::ClampLinear] = std::make_unique<Sampler>(device, SamplerMode::ClampLinear);
        m_samplers[SamplerMode::WrapPoint] = std::make_unique<Sampler>(device, SamplerMode::WrapPoint);
        m_samplers[SamplerMode::ClampPoint] = std::make_unique<Sampler>(device, SamplerMode::ClampPoint);
    }

    render_menu_bar();
    render_popups();
    render_save_review();
    render_about();
    render_header();
    render_tree_viewer();
    render_resource_manager();
    render_texture_viewer();
    render_object_editor();
    render_options_menu();
    render_preview();

    const auto active_editor = get_active_editor();
    if (!active_editor.expired()) {
        const auto editor = active_editor.lock();
        editor->render(dockspace_id);
    }
}

void Editor::open_file() {
    HR_INIT(S_OK);

    Microsoft::WRL::ComPtr<IFileOpenDialog> dialog;
    HR_ASSERT(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&dialog)));

    const COMDLG_FILTERSPEC filters[] = {
        { I18n::TW("file.filter.gui_files"), L"*.gui" }
    };

    HR_ASSERT(dialog->SetFileTypes(ARRAYSIZE(filters), filters));
    HR_ASSERT(dialog->SetDefaultExtension(L"gui"));
    HR_ASSERT(dialog->SetOptions(
        FOS_STRICTFILETYPES | FOS_PATHMUSTEXIST | FOS_FILEMUSTEXIST
    ));

    if (dialog->Show(nullptr) == HRESULT_FROM_WIN32(ERROR_CANCELLED)) {
        return;
    }

    Microsoft::WRL::ComPtr<IShellItem> item;
    HR_ASSERT(dialog->GetResult(&item));

    LPWSTR file_name;
    HR_ASSERT(item->GetDisplayName(SIGDN_FILESYSPATH, &file_name));

    return open_file(file_name);
}

namespace {

// Walks the UTF-8 code points of a string, invalid bytes are skipped
void for_each_codepoint(const std::string& text, const std::function<void(u32)>& callback) {
    for (size_t i = 0; i < text.size();) {
        const auto first = static_cast<unsigned char>(text[i]);
        u32 codepoint = 0;
        size_t length = 0;

        if (first < 0x80) {
            codepoint = first;
            length = 1;
        } else if ((first & 0xE0) == 0xC0) {
            codepoint = first & 0x1Fu;
            length = 2;
        } else if ((first & 0xF0) == 0xE0) {
            codepoint = first & 0x0Fu;
            length = 3;
        } else if ((first & 0xF8) == 0xF0) {
            codepoint = first & 0x07u;
            length = 4;
        } else {
            ++i;
            continue;
        }

        if (i + length > text.size()) {
            break;
        }

        for (size_t k = 1; k < length; ++k) {
            codepoint = (codepoint << 6) | (static_cast<unsigned char>(text[i + k]) & 0x3Fu);
        }

        callback(codepoint);
        i += length;
    }
}

[[nodiscard]] std::string read_text_file(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return {};
    }

    return { std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>() };
}

// Gui version of a file, or nothing when it is not a gui file at all.
// Files are checked before loading: loading an unsupported version would otherwise
// produce a silently empty document.
[[nodiscard]] std::optional<u32> read_gui_version(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        return std::nullopt;
    }

    u32 magic = 0;
    u32 version = 0;

    file.read(reinterpret_cast<char*>(&magic), sizeof magic);
    file.read(reinterpret_cast<char*>(&version), sizeof version);

    if (!file || magic != 0x495547) { // "GUI\0"
        return std::nullopt;
    }

    return version;
}

} // namespace

void Editor::open_file(const std::filesystem::path& path) {
    const auto version = read_gui_version(path);

    if (!version) {
        error_popup(I18n::T("error.not_gui_file"));
        return;
    }

    // Only MHXR is supported, MHW and MHGU files would open as an empty document
    if (*version != static_cast<u32>(GUIFile::Version::MHXR)) {
        error_popup(fmt::format("{} 0x{:06X} {}",
            I18n::T("error.unsupported_gui_version"), *version, I18n::T("error.mhxr_only")));
        return;
    }

    m_editors.emplace_back(std::make_shared<GUIEditor>(this, path));
    m_active_editor = m_editors.size() - 1;

    m_first_render = true;
}

void Editor::save_file() {
    const auto active_editor = get_active_editor();
    if (active_editor.expired()) {
        return;
    }

    const auto editor = active_editor.lock();

    // Always show what is about to be written and let the user confirm
    m_save_review_is_save_as = false;
    m_pending_save_as.clear();
    m_save_review_open = true;
}

void Editor::render_save_review() {
    if (!m_save_review_open) {
        return;
    }

    const auto active_editor = get_active_editor();
    if (active_editor.expired()) {
        m_save_review_open = false;
        return;
    }

    const auto editor = active_editor.lock();

    if (ImGui::Begin(I18n::T("dialog.save_changes"), &m_save_review_open, ImGuiWindowFlags_AlwaysAutoResize)) {
        const std::string target = m_save_review_is_save_as
            ? m_pending_save_as.string()
            : editor->get_path().string();

        ImGui::Text("%s", I18n::T("save.target_file"));
        ImGui::TextWrapped("%s", target.c_str());
        ImGui::Separator();

        const auto& changes = editor->get_changes();

        if (changes.empty()) {
            ImGui::TextColored({ 1.0f, 0.8f, 0.2f, 1.0f }, "%s", I18n::T("save.no_changes"));
            ImGui::TextWrapped("%s", I18n::T("save.byte_identical"));
            ImGui::TextWrapped("%s", I18n::T("save.tracked_only"));
        }

        for (const auto& change : changes) {
            const char* risk = change.Risk == 0 ? I18n::T("save.risk.low")
                : (change.Risk == 1 ? I18n::T("save.risk.medium") : I18n::T("save.risk.high"));

            ImGui::Text("[%s] %s: %s -> %s (0x%llX)",
                risk, change.Path.c_str(), change.OldValue.c_str(), change.NewValue.c_str(),
                static_cast<unsigned long long>(change.Offset));
        }

        ImGui::Separator();
        ImGui::Text("%s", I18n::T("save.everything_identical"));

        if (ImGui::Button(I18n::T("button.save"))) {
            if (m_save_review_is_save_as) {
                editor->save_file_as(m_pending_save_as);
            } else {
                editor->save_file();
            }

            m_save_review_open = false;
        }

        ImGui::SameLine();

        if (ImGui::Button(I18n::T("button.cancel"))) {
            m_save_review_open = false;
        }

        ImGui::End();
    }
}

void Editor::save_file_as() {
    const auto active_editor = get_active_editor();
    if (active_editor.expired()) {
        return;
    }

    HR_INIT(S_OK);

    Microsoft::WRL::ComPtr<IFileSaveDialog> dialog;
    HR_ASSERT(CoCreateInstance(CLSID_FileSaveDialog, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&dialog)));

    const COMDLG_FILTERSPEC filters[] = {
        { I18n::TW("file.filter.gui_files"), L"*.gui" }
    };

    HR_ASSERT(dialog->SetFileTypes(ARRAYSIZE(filters), filters));
    HR_ASSERT(dialog->SetDefaultExtension(L"gui"));
    HR_ASSERT(dialog->SetOptions(
        FOS_STRICTFILETYPES | FOS_PATHMUSTEXIST | FOS_OVERWRITEPROMPT
    ));

    if (dialog->Show(nullptr) == HRESULT_FROM_WIN32(ERROR_CANCELLED)) {
        return;
    }

    Microsoft::WRL::ComPtr<IShellItem> item;
    HR_ASSERT(dialog->GetResult(&item));

    LPWSTR file_name;
    HR_ASSERT(item->GetDisplayName(SIGDN_FILESYSPATH, &file_name));

    const std::wstring wpath = file_name;

    // Show the review dialog first, the file is only written when the user confirms
    m_pending_save_as = wpath;
    m_save_review_is_save_as = true;
    m_save_review_open = true;
}

void Editor::open_preview() {
    m_preview_open = true;
}

void Editor::select_chunk_dir() {
    m_settings.ChunkPath = open_folder_dialog(I18n::TW("dialog.select_chunk_dir")).string();
}

void Editor::select_native_dir() {
    m_settings.NativePath = open_folder_dialog(I18n::TW("dialog.select_native_dir")).string();
}

void Editor::select_arcfs_dir() {
    m_settings.ArcfsPath = open_folder_dialog(I18n::TW("dialog.select_arcfs_dir")).string();
}

std::filesystem::path Editor::open_file_dialog(std::wstring_view title,
    const std::vector<COMDLG_FILTERSPEC>& filters, std::wstring_view default_ext) const {
    HR_INIT(S_OK);

    Microsoft::WRL::ComPtr<IFileOpenDialog> dialog;
    HR_ASSERT(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&dialog)));
    HR_ASSERT(dialog->SetOptions(FOS_PATHMUSTEXIST | FOS_FILEMUSTEXIST | FOS_STRICTFILETYPES));

    HR_ASSERT(dialog->SetTitle(title.data()));
    HR_ASSERT(dialog->SetFileTypes(filters.size(), filters.data()));
    HR_ASSERT(dialog->SetDefaultExtension(default_ext.data()));

    if (dialog->Show(nullptr) == HRESULT_FROM_WIN32(ERROR_CANCELLED)) {
        return {};
    }

    Microsoft::WRL::ComPtr<IShellItem> item;
    LPWSTR path;

    HR_ASSERT(dialog->GetResult(&item));
    HR_ASSERT(item->GetDisplayName(SIGDN_FILESYSPATH, &path));

    return path;
}

std::filesystem::path Editor::open_folder_dialog(std::wstring_view title) const {
    HR_INIT(S_OK);

    Microsoft::WRL::ComPtr<IFileOpenDialog> dialog;
    HR_ASSERT(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&dialog)));
    HR_ASSERT(dialog->SetOptions(FOS_PATHMUSTEXIST | FOS_PICKFOLDERS));
    HR_ASSERT(dialog->SetTitle(title.data()));

    if (dialog->Show(nullptr) == HRESULT_FROM_WIN32(ERROR_CANCELLED)) {
        return {};
    }

    Microsoft::WRL::ComPtr<IShellItem> item;
    LPWSTR path;
    HR_ASSERT(dialog->GetResult(&item));
    HR_ASSERT(item->GetDisplayName(SIGDN_FILESYSPATH, &path));

    return path;
}

void Editor::render_menu_bar() {
    bool open_options_window = false;

    if (ImGui::BeginMainMenuBar()) {
        for (const auto& [name_key, items] : m_menu_items) {
            if (ImGui::BeginMenu(I18n::T(name_key.c_str()))) {
                for (const auto& item : items) {
                    const std::string label = item.Icon
                        ? std::string(item.Icon) + " " + I18n::T(item.TextKey)
                        : std::string(I18n::T(item.TextKey));

                    if (ImGui::MenuItem(label.c_str(), item.Shortcut, false, item.Enabled)) {
                        item.Callback(this);
                    }
                }

                ImGui::EndMenu();
            }
        }

        if (ImGui::BeginMenu(I18n::T("menu.tools"))) {
            const std::string themes_label = std::string(ICON_FA_PALETTE) + " " + I18n::T("menu.tools.themes");

            if (ImGui::BeginMenu(themes_label.c_str())) {
                if (ImGui::MenuItem(I18n::T("menu.tools.themes.refresh"))) {
                    m_theme_manager.refresh();
                }

                ImGui::Separator();

                if (ImGui::MenuItem(I18n::T("menu.tools.themes.default"))) {
                    m_theme_manager.apply_default_style();
                    m_settings.Theme = "";
                    m_settings.save();

                    capture_base_style();
                    apply_ui_scale();
                }

                for (const auto& [name, style] : m_theme_manager.get_styles()) {
                    if (ImGui::MenuItem(name.c_str())) {
                        m_theme_manager.apply_style(name);
                        m_settings.Theme = name;
                        m_settings.save();

                        capture_base_style();
                        apply_ui_scale();
                    }
                }

                ImGui::EndMenu();
            }

            const std::string options_label = std::string(ICON_FA_GEARS) + " " + I18n::T("menu.tools.options");
            if (ImGui::MenuItem(options_label.c_str())) {
                open_options_window = true;
            }

            if (ImGui::MenuItem(I18n::T("menu.tools.reset_layout"))) {
                ImGui::ClearIniSettings();

                // Forces Editor::render() to rebuild the default layout on the next frame
                m_settings.LayoutVersion = 0;
            }

            const std::string extract_label = std::string(ICON_FA_FILE_PEN) + " " + I18n::T("menu.tools.extract_object_data");
            if (ImGui::MenuItem(extract_label.c_str())) {
                dump_object_data();
            }

            if (ImGui::IsItemHovered()) {
                ImGui::SetTooltip("%s", I18n::T("menu.tools.extract_object_data.tooltip"));
            }

            ImGui::EndMenu();
        }

        // Help sits last, right next to Tools
        const char* help_text = I18n::T("menu.help");

        if (ImGui::BeginMenu(help_text)) {
            if (ImGui::MenuItem(I18n::T("menu.help.about"))) {
                m_about_open = true;
            }

            ImGui::EndMenu();
        }

        ImGui::EndMainMenuBar();
    }

    if (open_options_window) {
        ImGui::OpenPopup((std::string(I18n::T("options.title")) + "##OptionsWindow").c_str());
        m_options_menu_open = true;
    }
}

void Editor::render_options_menu() {
    constexpr float window_width = 900.0f;
    const float panel_width = window_width - ImGui::GetStyle().WindowPadding.x * 2.0f;
    const float input_text_width = panel_width - 220.0f - ImGui::GetStyle().ItemSpacing.x * 2.0f;

    ImGui::SetNextWindowSize(ImVec2(window_width, 0), ImGuiCond_Always);
    const std::string options_title = std::string(I18n::T("options.title")) + "##OptionsWindow";

    if (ImGui::BeginPopupModal(options_title.c_str(), &m_options_menu_open,
        ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize)) {

        const std::string general_label = std::string(ICON_FA_BARS) + " " + I18n::T("options.group.general");
        ImGui::BeginGroupPanel(general_label.c_str(), { panel_width, 0 });

        // MHXR resolves every texture through the ARCFS directory, these two only ever fed
        // the MHW loader which is no longer reachable. Kept visible but disabled so nobody
        // wonders where they went.
        ImGui::BeginDisabled();

        ImGui::SetNextItemWidth(input_text_width);
        ImGui::InputText(I18n::T("options.chunk_dir"), &m_settings.ChunkPath);
        ImGui::SameLine();
        if (ImGui::Button("...##ChunkDir")) {
            select_chunk_dir();
        }

        ImGui::SetNextItemWidth(input_text_width);
        ImGui::InputText(I18n::T("options.native_dir"), &m_settings.NativePath);
        ImGui::SameLine();
        if (ImGui::Button("...##NativeDir")) {
            select_native_dir();
        }

        ImGui::EndDisabled();

        ImGui::SetNextItemWidth(input_text_width);
        ImGui::InputText(I18n::T("options.arcfs_dir"), &m_settings.ArcfsPath);
        ImGui::SameLine();
        if (ImGui::Button("...##ArcfsDir")) {
            select_arcfs_dir();
        }

        ImGui::EndGroupPanel();

        const std::string optimization_label = std::string(ICON_FA_BOLT) + " " + I18n::T("options.group.optimization");
        ImGui::BeginGroupPanel(optimization_label.c_str(), { panel_width, 0 });

        ImGui::Text("%s", I18n::T("options.allow_multiple_refs"));

        if (ImGui::IsItemHovered()) {
            ImGui::BeginTooltip();
            ImGui::Text("%s", I18n::T("options.allow_multiple_refs.tooltip1"));
            ImGui::Text("%s", I18n::T("options.allow_multiple_refs.tooltip2"));
            ImGui::EndTooltip();
        }

        ImGui::Indent();

        // Only MHW and MHGU rebuild the key value blocks while saving, MHXR patches the
        // original bytes instead and never touches them, so these have no effect.
        ImGui::BeginDisabled();

        ImGui::Checkbox(I18n::T("options.kv8"), &m_settings.AllowMultipleKV8References);
        ImGui::Checkbox(I18n::T("options.kv32"), &m_settings.AllowMultipleKV32References);
        ImGui::Checkbox(I18n::T("options.kv128"), &m_settings.AllowMultipleKV128References);

        ImGui::EndDisabled();

        ImGui::Unindent();
        ImGui::EndGroupPanel();

        const std::string utilities_label = std::string(ICON_FA_WRENCH) + " " + I18n::T("options.group.utilities");
        ImGui::BeginGroupPanel(utilities_label.c_str(), { panel_width, 0 });

        {
            const char* lang_labels[] = { "中文", "English" };
            int lang_index = (m_settings.Language == "en") ? 1 : 0;

            if (ImGui::Combo(I18n::T("options.ui_language"), &lang_index, lang_labels, 2)) {
                m_settings.Language = (lang_index == 0) ? "zh" : "en";
                I18n::set_language(m_settings.Language);
                g_ui_language = m_settings.Language;
                m_settings.save();
            }

            if (ImGui::Checkbox(I18n::T("options.auto_backup"), &m_settings.AutoBackup)) {
                m_settings.save();
            }

            int font_size = static_cast<int>(m_settings.FontSize);

            if (ImGui::SliderInt(I18n::T("options.font_size"), &font_size, 8, 72, "%d")) {
                // The setting has to follow the drag, otherwise the next frame rebuilds the
                // slider from the old value and it snaps back. The atlas itself is only
                // rebuilt once the value is settled.
                m_settings.FontSize = static_cast<float>(font_size);
            }

            if (ImGui::IsItemDeactivatedAfterEdit()) {
                m_settings.save();
                apply_ui_scale();
            }
        }

        if (ImGui::Checkbox(I18n::T("options.auto_adjust_keyframes"), &m_settings.AutoAdjustKeyFrames)) {
            if (m_settings.AutoAdjustKeyFrames) {
                m_popup_queue.emplace(I18n::T("options.auto_adjust_keyframes.warning.title"),
                    I18n::T("options.auto_adjust_keyframes.warning.body"),
                    PopupType::OkCancel, [this](YesNoCancelPopupResult result, const auto&) {
                    if (result == YesNoCancelPopupResult::Cancel) {
                        m_settings.AutoAdjustKeyFrames = false;
                    }
                });
            }
        }

        if (ImGui::IsItemHovered()) {
            ImGui::BeginTooltip();
            ImGui::Text("%s", I18n::T("options.auto_adjust_keyframes.tooltip"));
            ImGui::EndTooltip();
        }

        ImGui::EndGroupPanel();

        ImGui::NewLine();
        if (ImGui::Button(I18n::T("button.ok"))) {
            m_settings.save();
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

void Editor::render_popups() {
    const std::string error_title = std::string(I18n::T("error.title")) + "##SelectFile";
    const std::string generic_error_title = std::string(I18n::T("error.title")) + "##GenericError";

    if (m_error_popup_select_file_open) {
        ImGui::OpenPopup(error_title.c_str());
        m_error_popup_select_file_open = false;
    }

    if (ImGui::BeginPopup(error_title.c_str())) {
        ImGui::Text("%s", I18n::T("error.select_file"));
        if (ImGui::Button(I18n::T("button.ok"))) {
            ImGui::CloseCurrentPopup();
        }

        ImGui::SameLine();
        if (ImGui::Button(I18n::T("button.copy"))) {
            ImGui::SetClipboardText(I18n::T("error.select_file"));
        }

        ImGui::EndPopup();
    }

    if (m_error_popup_open) {
        ImGui::OpenPopup(generic_error_title.c_str());
        m_error_popup_open = false;
    }

    if (ImGui::BeginPopup(generic_error_title.c_str())) {
        ImGui::Text("%s", m_error_popup_message.c_str());
        if (ImGui::Button(I18n::T("button.ok"))) {
            ImGui::CloseCurrentPopup();
        }

        ImGui::SameLine();
        if (ImGui::Button(I18n::T("button.copy"))) {
            ImGui::SetClipboardText(m_error_popup_message.c_str());
        }

        ImGui::EndPopup();
    }

    if (!m_popup_queue.empty()) {
        ImGui::PushID("YesNoCancelPopupQueue");

        auto& popup = m_popup_queue.front();
        if (!ImGui::IsPopupOpen(popup.Title.c_str())) {
            ImGui::OpenPopup(popup.Title.c_str());
        }

        if (ImGui::BeginPopupModal(m_popup_queue.front().Title.c_str(), nullptr, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_AlwaysAutoResize)) {
            ImGui::Text("%s", popup.Message.c_str());

            bool new_line = false;

            if (popup.Type & PopupType::Ok) {
                new_line = true;

                if (ImGui::Button(I18n::T("button.ok"))) {
                    popup.Callback(YesNoCancelPopupResult::Ok, popup.UserData);

                    m_popup_queue.pop();
                    ImGui::CloseCurrentPopup();
                }
            }

            if (popup.Type & PopupType::Yes) {
                if (new_line) {
                    ImGui::SameLine();
                } else {
                    new_line = true;
                }

                if (ImGui::Button(I18n::T("button.yes"))) {
                    popup.Callback(YesNoCancelPopupResult::Yes, popup.UserData);

                    m_popup_queue.pop();
                    ImGui::CloseCurrentPopup();
                }
            }

            if (popup.Type & PopupType::No) {
                if (new_line) {
                    ImGui::SameLine();
                } else {
                    new_line = true;
                }

                if (ImGui::Button(I18n::T("button.no"))) {
                    popup.Callback(YesNoCancelPopupResult::No, popup.UserData);

                    m_popup_queue.pop();
                    ImGui::CloseCurrentPopup();
                }
            }

            if (popup.Type & PopupType::Cancel) {
                if (new_line) {
                    ImGui::SameLine();
                }

                if (ImGui::Button(I18n::T("button.cancel"))) {
                    popup.Callback(YesNoCancelPopupResult::Cancel, popup.UserData);

                    m_popup_queue.pop();
                    ImGui::CloseCurrentPopup();
                }
            }

            ImGui::EndPopup();
        }

        ImGui::PopID();
    }
}

void Editor::render_header() {
    ImGui::Begin(I18n::T("window.header"));

    const auto active_editor = get_active_editor();
    if (!active_editor.expired()) {
        const auto editor = active_editor.lock();
        editor->render_header();
    }

    ImGui::End();
}

void Editor::render_about() {
    if (!m_about_open) {
        return;
    }

    ImGui::SetNextWindowSize({ 620, 560 }, ImGuiCond_Always);

    if (ImGui::Begin(I18n::T("about.title"), &m_about_open, ImGuiWindowFlags_NoDocking)) {
        ImGui::TextUnformatted(I18n::T("about.name"));
        ImGui::TextUnformatted(I18n::T("about.version"));
        ImGui::Text("%s Mint2333", I18n::T("about.author"));

        ImGui::Separator();
        ImGui::TextUnformatted(I18n::T("about.support"));
        ImGui::Indent();

        ImGui::TextWrapped("%s", I18n::T("about.support.mhxr"));
        ImGui::TextWrapped("%s", I18n::T("about.support.reject"));
        ImGui::TextWrapped("%s", I18n::T("about.support.upstream"));
        ImGui::Unindent();

        ImGui::Separator();
        ImGui::TextUnformatted(I18n::T("about.save"));
        ImGui::Indent();

        ImGui::TextWrapped("%s", I18n::T("about.patch_saving"));
        ImGui::Spacing();

        ImGui::TextUnformatted(I18n::T("about.save.yes"));

        static const char* const savable[] = {
            "about.save.line.header",
            "about.save.line.object",
            "about.save.line.misc"
        };

        for (const char* key : savable) {
            ImGui::Bullet();
            ImGui::TextWrapped("%s", I18n::T(key));
        }

        ImGui::Spacing();
        ImGui::TextUnformatted(I18n::T("about.save.no"));

        static const char* const not_savable[] = {
            "about.save.line.string",
            "about.save.line.param",
            "about.save.line.anim"
        };

        for (const char* key : not_savable) {
            ImGui::Bullet();
            ImGui::TextWrapped("%s", I18n::T(key));
        }

        ImGui::Unindent();

        ImGui::Separator();
        ImGui::Text("%s %s", I18n::T("about.commit"), APP_GIT_COMMIT);
        ImGui::SameLine();
        ImGui::TextDisabled("(?)");

        if (ImGui::IsItemHovered()) {
            ImGui::SetTooltip("%s", I18n::T("about.commit_hint"));
        }

        ImGui::Text("%s %s", I18n::T("about.base_tag"), APP_GIT_TAG);
        ImGui::Text("%s %d", I18n::T("about.commits"), APP_GIT_COMMITS_AHEAD);
        ImGui::Text("%s %s", I18n::T("about.build_time"), APP_BUILD_TIMESTAMP);

        ImGui::End();
    }
}

void Editor::render_tree_viewer() {
    ImGuiWindowClass cls;
    cls.DockNodeFlagsOverrideSet = ImGuiDockNodeFlags_NoTabBar;

    ImGui::SetNextWindowClass(&cls);
    ImGui::Begin(I18n::T("window.tree_viewer"));

    if (ImGui::BeginTabBar("##TabBarEditors", ImGuiTabBarFlags_Reorderable)) {
        size_t to_close = -1;
        size_t selected = -1;

        for (auto i = 0; i < m_editors.size(); ++i) {
            bool open = true;
            const auto& editor = m_editors[i];
            if (ImGui::BeginTabItem(editor->get_name().c_str(), &open)) {
                ImGui::PushID(i);
                ImGui::BeginChild("##ScrollArea");

                selected = i;
                editor->render_tree_viewer();

                ImGui::EndChild();
                ImGui::PopID();

                ImGui::EndTabItem();
            }

            if (!open) {
                to_close = i;
            }
        }

        m_active_editor = selected;

        if (to_close != -1) {
            m_editors.erase(m_editors.begin() + to_close);
            if (m_active_editor == to_close) {
                m_active_editor = m_editors.empty() ? -1 : 0;
            } else if (m_active_editor > to_close) {
                --m_active_editor;
            }
        }

        ImGui::EndTabBar();
    }

    ImGui::End();
}

void Editor::render_resource_manager() const {
    ImGui::Begin(I18n::T("window.resource_manager"));

    const auto active_editor = get_active_editor();
    if (!active_editor.expired()) {
        const auto editor = active_editor.lock();
        editor->render_resource_manager();
    }

    ImGui::End();
}

void Editor::render_texture_viewer() const {
    ImGui::Begin(I18n::T("window.texture_viewer"));

    const auto active_editor = get_active_editor();
    if (!active_editor.expired()) {
        const auto editor = active_editor.lock();
        editor->render_texture_viewer();
    }

    ImGui::End();
}

void Editor::render_object_editor() {
    
}

void Editor::render_preview() {
    if (!m_preview_open) {
        return;
    }

    if (ImGui::Begin(I18n::T("window.preview"), &m_preview_open)) {
        const auto active_editor = get_active_editor();
        if (!active_editor.expired()) {
            const auto editor = active_editor.lock();
            editor->render_preview();
        }
    }

    ImGui::End();
}

void Editor::load_fonts(const bool rebuild_device_objects) {
    // ImGui bakes glyphs at whatever size is bound while rendering (style.FontSizeBase),
    // so the size here only fixes the default size of each font source. Changing the font
    // size therefore needs no atlas rebuild, only apply_ui_scale().
    constexpr float base_size = 16.0f;

    auto* fonts = ImGui::GetIO().Fonts;

    fonts->Clear();

    ImFontConfig config;
    config.MergeMode = true;
    config.GlyphMinAdvanceX = base_size;
    config.GlyphMaxAdvanceX = base_size;
    static constexpr ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };

    fonts->AddFontFromFileTTF("./fonts/CascadiaMono.ttf", base_size);
    fonts->AddFontFromFileTTF("./fonts/Font Awesome 6 Free-Solid-900.otf", base_size, &config, icon_ranges);

    // Merge a CJK font so Chinese text renders correctly (CascadiaMono has no CJK glyphs).
    // Only the collected glyphs are rasterized, whole CJK blocks would waste atlas space
    // on tens of thousands of characters that never appear.
    {
        const std::filesystem::path cjk = "C:\\Windows\\Fonts\\msyh.ttc";
        if (std::filesystem::exists(cjk)) {
            ImVector<ImWchar> cjk_ranges;
            m_glyphs.BuildRanges(&cjk_ranges);

            ImFontConfig cjk_config;
            cjk_config.MergeMode = true;
            fonts->AddFontFromFileTTF(cjk.string().c_str(), base_size, &cjk_config, cjk_ranges.Data);
        }
    }
    fonts->Build();

    config.FontDataOwnedByAtlas = false;
    fonts->AddFontFromMemoryTTF((void*)tahoma, sizeof tahoma, base_size + 1.0f, &config);
    fonts->Build();
    ImGui::MergeIconsWithLatestFont(base_size);

    if (rebuild_device_objects) {
        ImGui_ImplDX11_InvalidateDeviceObjects();
        ImGui_ImplDX11_CreateDeviceObjects();
    }
}

void Editor::add_glyph_text(const std::string& text) {
    for_each_codepoint(text, [this](const u32 codepoint) {
        if (codepoint > IM_UNICODE_CODEPOINT_MAX || m_glyphs.GetBit(codepoint)) {
            return;
        }

        m_glyphs.AddChar(static_cast<ImWchar>(codepoint));
        m_glyphs_dirty = true;
    });
}

void Editor::collect_static_glyphs() {
    m_glyphs.AddRanges(ImGui::GetIO().Fonts->GetGlyphRangesDefault());

    static constexpr ImWchar icon_ranges[] = { ICON_MIN_FA, ICON_MAX_FA, 0 };
    m_glyphs.AddRanges(icon_ranges);

    // Every string the UI can show on its own comes from the language tables
    for (const char* language : { "zh", "en" }) {
        add_glyph_text(read_text_file(std::filesystem::path("lang") / (std::string(language) + ".toml")));
    }
}

void Editor::rebuild_fonts_if_needed() {
    if (!m_glyphs_dirty) {
        return;
    }

    m_glyphs_dirty = false;

    load_fonts(true);
    apply_ui_scale();
}

void Editor::capture_base_style() {
    m_base_style = ImGui::GetStyle();
}

void Editor::apply_ui_scale() {
    // Every spacing value in the themes is authored for a 16px font
    const float scale = m_settings.FontSize / 16.0f;

    ImGuiStyle style = m_base_style;
    style.ScaleAllSizes(scale);
    style.FontSizeBase = m_settings.FontSize;
    ImGui::GetStyle() = style;
}

void Editor::dump_object_data() const {
    const auto dir = open_folder_dialog(I18n::TW("dialog.select_search_dir"));

    // The dialog returns an empty path when the user cancels
    if (dir.empty()) {
        return;
    }

    std::error_code ec;
    if (!std::filesystem::is_directory(dir, ec)) {
        return;
    }

    nlohmann::json data = nlohmann::json::object();
    u32 scanned = 0;
    u32 failed = 0;

    auto object_contains_field = [](const nlohmann::json& object, std::string_view name) {
        if (!object.contains("Fields") || !object.at("Fields").is_array()) {
            return false;
        }

        return std::ranges::any_of(object.at("Fields"), [&](const auto& field) {
            return field.value("Name", "") == name;
        });
    };

    auto add_object = [&](const GUIFile& gui, const GUIObject& obj) {
        const char* type_name = enum_to_string(obj.Type);

        // Real files contain out of range indices, they must not crash the scan
        const u64 max = std::min<u64>(
            static_cast<u64>(obj.InitParamIndex) + obj.InitParamNum,
            gui.m_init_params.size()
        );

        auto& jobj = data[type_name];
        if (!jobj.is_object()) {
            jobj = nlohmann::json::object();
            jobj["Name"] = type_name;
            jobj["Fields"] = nlohmann::json::array();
        }

        for (u64 i = obj.InitParamIndex; i < max; ++i) {
            const auto& param = gui.m_init_params[i];

            if (object_contains_field(jobj, param.Name)) {
                continue;
            }

            jobj["Fields"].push_back({
                { "Name", param.Name },
                { "Type", static_cast<u32>(param.Type) }
            });
        }
    };

    std::filesystem::recursive_directory_iterator it(dir, ec);
    const std::filesystem::recursive_directory_iterator end{};

    while (!ec && it != end) {
        const auto& entry = *it;

        if (entry.is_regular_file(ec) && entry.path().extension() == ".gui") {
            ++scanned;

            try {
                // One file per document, reusing a single instance leaves data behind
                GUIFile gui{};

                BinaryReader reader(entry.path().string());
                gui.load_from(reader);

                for (const auto& obj : gui.m_objects) {
                    add_object(gui, obj);
                }
            }
            catch (const std::exception& e) {
                ++failed;
                spdlog::warn("Skipped {}: {}", entry.path().string(), e.what());
            }
        }

        it.increment(ec);
    }

    if (ec) {
        spdlog::warn("Stopped scanning {} ({})", dir.string(), ec.message());
    }

    const auto output = std::filesystem::current_path() / "cGUIObject.json";
    std::ofstream out(output);

    if (!out) {
        spdlog::error("Failed to write {}", output.string());
        return;
    }

    out << data.dump(4);

    const bool ok = failed == 0;

    ImGuiToast toast(ok ? ImGuiToastType_Success : ImGuiToastType_Warning);
    toast.set_title(I18n::T("toast.export_done"));
    toast.set_type(ok ? ImGuiToastType_Success : ImGuiToastType_Warning);
    toast.set_content("%s", fmt::format("{0} {1}\n{2} {3}\n{4} {5}",
        I18n::T("toast.export_scanned"), scanned,
        I18n::T("toast.export_failed"), failed,
        I18n::T("toast.export_output"), output.string()).c_str());

    ImGui::InsertNotification(toast);
}

void Editor::handle_file_drop(HDROP drop) {
    char file_name[MAX_PATH];

    const auto count = DragQueryFileA(drop, 0xFFFFFFFF, nullptr, 0);
    for (auto i = 0; i < count; ++i) {
        if (DragQueryFileA(drop, i, file_name, sizeof file_name)) {
            const auto path = std::filesystem::path(file_name);
            if (path.extension() == ".gui") {
                open_file(path);
            }
        }
    }

    DragFinish(drop);
}
