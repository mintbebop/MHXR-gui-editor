#include "pch.h"
#include "App.h"
#include "GUIEditor.h"
#include "IconFontAwesome.h"
#include "I18n.h"

#include <imgui_stdlib.h>
#include <fmt/format.h>


void GUIEditor::render_resource_manager() {
    {
        static constexpr std::array ResourceTypes = {
            "Texture",
            "Message",
            "Resource",
            "GeneralResource"
        };

        static std::string name;
        static u32 id = 0;
        static int type = 0;
        static ObjectType obj_type = ObjectType::None;

        const char* const add_popup_id = "AddNewResource##popup";

        if (ImGui::Button(I18n::T("resource.add_new"))) {
            ImGui::OpenPopup(add_popup_id);

            name = "";
            id = m_file.get_unused_id(m_file.m_textures);
            type = 0;
        }

        if (ImGui::BeginPopupModal(add_popup_id)) {
            ImGui::Combo(I18n::T("resource.type"), &type, ResourceTypes.data(), ResourceTypes.size());
            if (type == 0) {
                ImGui::InputText(I18n::T("resource.name"), &name);
            } else if (type == 3) {
                if (ImGui::BeginCombo(I18n::T("resource.object_type"), enum_to_string(obj_type))) {
                    for (const auto& [key, value] : ObjectTypeNames) {
                        if (ImGui::Selectable(value, obj_type == key)) {
                            obj_type = key;
                        }
                    }

                    ImGui::EndCombo();
                }
            }

            ImGui::InputScalar(I18n::T("resource.id"), ImGuiDataType_U32, &id, nullptr, nullptr, "%u");
            ImGui::Separator();

            if (ImGui::Button(I18n::T("resource.add"))) {
                switch (type) {
                case 0: m_file.insert_texture({ .ID = id, .Name = name }); break;
                case 1: m_file.m_messages.push_back({ .ID = id }); break;
                case 2: m_file.m_resources.push_back({ .ID = id }); break;
                case 3: m_file.m_general_resources.push_back({ .ID = id }); break;
                default: break;
                }

                ImGui::CloseCurrentPopup();
            }

            ImGui::SameLine();
            if (ImGui::Button(I18n::T("button.cancel"))) {
                ImGui::CloseCurrentPopup();
            }

            ImGui::EndPopup();
        }
    }

    constexpr ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_OpenOnDoubleClick;
    const u32 u32_step = 1;
    const u32 u32_fast_step = 10;

    for (auto i = 0; i < m_file.m_textures.size(); ++i) {
        ImGuiTreeNodeFlags node_flags = flags;

        auto& tex = m_file.m_textures[i];

        if (m_selected_texture == i) {
            node_flags |= ImGuiTreeNodeFlags_Selected;
        }

        const bool has_error = tex.ErrorCode != TextureLoadError::None;
        const std::string label = has_error
            ? fmt::format("[!] {} | {}", tex.Name, tex.Path)
            : fmt::format("{} | {}", tex.Name, tex.Path);

        const bool open = ImGui::TreeNodeEx(label.c_str(), node_flags);
        if (ImGui::IsItemClicked()) {
            m_selected_texture = i;
        }

        if (has_error && ImGui::IsItemHovered()) {
            const std::string error = texture_error_text(tex);
            ImGui::SetTooltip("%s", error.c_str());
        }

        if (ImGui::BeginPopupContextItem()) {
            if (ImGui::MenuItem(I18n::T("menu.copy_path"))) {
                ImGui::SetClipboardText(tex.ResolvedPath.empty() ? tex.Path.c_str() : tex.ResolvedPath.c_str());
            }

            if (ImGui::MenuItem(I18n::T("resource.delete"))) {
                m_owner->add_popup(I18n::T("resource.delete_title"), I18n::T("resource.delete_body"), PopupType::YesCancel,
                    [this, i](auto result, const auto&) {
                    if (result == YesNoCancelPopupResult::Yes) {
                        m_file.m_textures.erase(m_file.m_textures.begin() + i);
                    }
                });
            }

            ImGui::EndPopup();
        }

        if (open) {
            if (has_error) {
                const std::string error = texture_error_text(tex);
                ImGui::TextColored({ 1.0f, 0.55f, 0.2f, 1.0f }, "%s", error.c_str());

                ImGui::SameLine();
                const std::string copy_label = std::string(I18n::T("button.copy")) + "##copy" + std::to_string(i);
                if (ImGui::SmallButton(copy_label.c_str())) {
                    ImGui::SetClipboardText(tex.ResolvedPath.empty() ? tex.Path.c_str() : tex.ResolvedPath.c_str());
                }
            }

            ImGui::InputScalar(I18n::T("resource.id"), ImGuiDataType_U32, &tex.ID, &u32_step, &u32_fast_step);

            ImGui::InputScalarN(I18n::T("resource.texture_rect"), ImGuiDataType_U16, &tex.Left, 4, &u32_step, &u32_fast_step);

            ImGui::InputFloat4(I18n::T("resource.clamp"), &tex.Clamp[0], "%.3f");
            ImGui::InputFloat2(I18n::T("resource.inv_size"), &tex.InvSize.x, "%.8f");

            {
                std::string name = tex.Name;
                if (ImGui::InputText(I18n::T("resource.name"), &name)) {
                    FieldEdit::reject(fmt::format("Textures[{}].Name", i));
                }
            }

            {
                std::string path = tex.Path;
                if (ImGui::InputText(I18n::T("resource.path"), &path)) {
                    FieldEdit::reject(fmt::format("Textures[{}].Path", i));
                }
            }
            ImGui::SameLine();

            const auto& settings = m_owner->get_settings();

            if (ImGui::Button("...")) {
                if (settings.ChunkPath.empty()) {
                    m_owner->error_file_open();
                } else {
                    const auto path = m_owner->open_file_dialog(
                        I18n::TW("dialog.select_texture"),
                        { { I18n::TW("file.filter.tex_files"), L"*.tex" } }, L"tex");
                    if (!path.empty()) {
                        std::filesystem::path relpath;
                        if (m_file.is_mhgu()) {
                            relpath = std::filesystem::relative(path, settings.ArcfsPath);
                        } else {
                            relpath = std::filesystem::relative(path, settings.ChunkPath);
                            if (relpath.empty()) {
                                relpath = std::filesystem::relative(path, settings.NativePath);
                            }
                        }

                        tex.Path = relpath.replace_extension().generic_string();

                        BinaryReader reader(path);
                        tex.RenderTexture.load_from(reader, m_file.is_mhgu(), m_app->get_device().Get(), m_app->get_context().Get());
                    }
                }
            }

            const std::string reload_label = std::string(ICON_FA_ARROW_ROTATE_RIGHT) + " " + I18n::T("resource.reload");

            if (ImGui::Button(reload_label.c_str())) {
                if (settings.ChunkPath.empty() && settings.NativePath.empty()) {
                    m_owner->error_file_open();
                } else {
                    std::filesystem::path path;

                    if (m_file.is_mhgu()) {
                        path = std::filesystem::path(settings.ArcfsPath) / tex.Path;
                        path.replace_extension("tex");
                    } else {
                        path = std::filesystem::path(settings.NativePath) / tex.Path;
                        path.replace_extension("tex");

                        if (!exists(path)) {
                            path = std::filesystem::path(settings.ChunkPath) / tex.Path;
                            path.replace_extension("tex");
                        }
                    }

                    try {
                        BinaryReader reader(path);
                        tex.RenderTexture.load_from(reader, m_file.is_mhgu(), m_app->get_device().Get(), m_app->get_context().Get());
                    } catch (...) {
                        m_owner->error_popup(I18n::T("error.texture.reload_failed"));
                    }
                }
            }

            ImGui::SameLine();
            if (ImGui::Button(I18n::T("resource.populate_dimensions")) && tex.RenderTexture.is_valid()) {
                tex.Left = 0;
                tex.Top = 0;
                tex.Width = static_cast<u16>(tex.RenderTexture.get_width());
                tex.Height = static_cast<u16>(tex.RenderTexture.get_height());
                tex.InvSize.x = 1.0f / tex.Width;
                tex.InvSize.y = 1.0f / tex.Height;
            }

            ImGui::TreePop();
        }
    }
}
