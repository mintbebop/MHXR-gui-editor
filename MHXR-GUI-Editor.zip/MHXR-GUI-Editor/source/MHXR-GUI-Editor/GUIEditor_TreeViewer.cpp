#include "pch.h"
#include "GUIEditor.h"
#include "RichText.h"

#include <fmt/format.h>


void GUIEditor::render_tree_viewer() {
    // Keep the input boxes at a comfortable width
    ImGui::PushItemWidth(240.0f);

    // Name filter for the lists below. The keyword lives on the editor so switching tabs
    // starts with a clean filter instead of reusing the keyword of another file.
    ImGui::SetNextItemWidth(240.0f);

    const bool pressed_enter = ImGui::InputTextWithHint("##tree_search", I18n::T("tree.search_hint"),
        m_search, sizeof(m_search), ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SameLine();

    if (pressed_enter || ImGui::Button(I18n::T("tree.search"))) {
        m_search_applied = m_search;
    }

    ImGui::SameLine();

    if (ImGui::Button(I18n::T("tree.clear"))) {
        m_search[0] = '\0';
        m_search_applied.clear();
    }

    if (!m_search_applied.empty()) {
        // Counted while the sections below were drawn on the previous frame
        if (m_search_matches == 0) {
            ImGui::TextColored({ 1.0f, 0.8f, 0.2f, 1.0f }, "%s", I18n::T("tree.no_match"));
        } else {
            ImGui::Text("%s %d", I18n::T("tree.match_count"), m_search_matches);
        }
    }

    std::string needle = m_search_applied;
    for (char& c : needle) {
        c = static_cast<char>(::tolower(static_cast<unsigned char>(c)));
    }

    const bool searching = !needle.empty();
    int matches_found = 0;

    const auto matches = [&needle](const std::string& text) {
        if (needle.empty()) {
            return true;
        }

        std::string lowered;
        lowered.reserve(text.size());

        for (const char c : text) {
            lowered.push_back(static_cast<char>(::tolower(static_cast<unsigned char>(c))));
        }

        return lowered.find(needle) != std::string::npos;
    };

    // Ids are matched as decimal and as hex, so both 255 and ff find the same entry
    const auto id_text = [](const u32 id) {
        return fmt::format("{} {:#x} {:x}", id, id, id);
    };

    // One filtered section. Sections without a single match stay hidden and sections with
    // matches open themselves, otherwise the hits would be stuck inside collapsed nodes.
    const auto section = [&](const char* title, auto& list, const auto& text_of, const auto& render_one) {
        int visible = 0;

        for (u32 i = 0; i < list.size(); ++i) {
            if (matches(text_of(list[i], i))) {
                ++visible;
            }
        }

        if (searching) {
            matches_found += visible;

            if (visible == 0) {
                return;
            }

            ImGui::SetNextItemOpen(true);
        }

        if (ImGui::TreeNodeEx(title, ImGuiTreeNodeFlags_SpanAvailWidth)) {
            for (u32 i = 0; i < list.size(); ++i) {
                if (!matches(text_of(list[i], i))) {
                    continue;
                }

                render_one(list[i], i);
            }

            ImGui::TreePop();
        }
    };

    section("Animations", m_file.m_animations,
        [&](const GUIAnimation& anim, u32) { return fmt::format("{} {}", anim.Name, id_text(anim.ID)); },
        [this](GUIAnimation& anim, u32) { render_animation(anim); });

    section("Objects", m_file.m_objects,
        [&](const GUIObject& obj, u32) { return fmt::format("{} {}", obj.Name, id_text(obj.ID)); },
        [this](GUIObject& obj, u32) { render_object(obj); });

    section("Sequences", m_file.m_sequences,
        [&](const GUISequence& seq, u32) { return fmt::format("{} {}", seq.Name, id_text(seq.ID)); },
        [this](GUISequence& seq, u32) { render_sequence(seq); });

    section("ObjectSequences", m_file.m_obj_sequences,
        [](const GUIObjectSequence&, const u32 index) { return std::to_string(index); },
        [this](GUIObjectSequence& objseq, u32) { render_obj_sequence(objseq); });

    section("InitParams", m_file.m_init_params,
        [](const GUIInitParam& param, u32) { return param.Name; },
        [this](GUIInitParam& param, u32) { render_init_param(param); });

    // Params carries its own context menu, so it cannot go through section()
    {
        int visible = 0;

        for (const auto& param : m_file.m_params) {
            if (matches(param.Name)) {
                ++visible;
            }
        }

        if (!searching || visible > 0) {
            if (searching) {
                matches_found += visible;
                ImGui::SetNextItemOpen(true);
            }

            const bool open = ImGui::TreeNodeEx("Params", ImGuiTreeNodeFlags_SpanAvailWidth);
            bool open_add_param_popup = false;

            if (ImGui::BeginPopupContextItem("Params")) {
                if (ImGui::MenuItem("Add New (WIP)")) {
                    open_add_param_popup = true;
                }

                ImGui::EndPopup();
            }

            if (open) {
                for (auto& param : m_file.m_params) {
                    if (!matches(param.Name)) {
                        continue;
                    }

                    render_param(param);
                }

                ImGui::TreePop();
            }
        }
    }

    m_visited_instances.clear();

    section("Instances (List View)", m_file.m_instances,
        [&](const GUIInstance& inst, u32) { return fmt::format("{} {}", inst.Name, id_text(inst.ID)); },
        [this](GUIInstance& inst, u32) { render_instance(inst); });

    section("FontFilters", m_file.m_font_filters,
        [&](const std::shared_ptr<GUIFontFilter>& filter, u32) { return id_text(filter->ID); },
        [this](const std::shared_ptr<GUIFontFilter>& filter, u32) { render_font_filter(filter); });

    section("Flows", m_file.m_flows,
        [&](const GUIFlow& flow, u32) { return fmt::format("{} {}", flow.Name, id_text(flow.ID)); },
        [this](GUIFlow& flow, const u32 index) { render_flow(flow, index); });

    section("FlowProcesses", m_file.m_flow_processes,
        [](const GUIFlowProcess&, const u32 index) { return std::to_string(index); },
        [this](GUIFlowProcess& process, const u32 index) { render_flow_process(process, index); });

    // Nothing searchable in these, they would only bury the actual results
    if (!searching) {
        if (ImGui::TreeNodeEx("Instances", ImGuiTreeNodeFlags_SpanAvailWidth)) {
            m_visited_instances.clear();

            for (const auto inst : m_file.m_root_instances) {
                if (inst >= m_file.m_instances.size()) {
                    continue;
                }

                render_instance(m_file.m_instances[inst]);
            }

            ImGui::TreePop();
        }

        if (m_file.is_mhxr()) {
            if (ImGui::TreeNodeEx("Fonts", ImGuiTreeNodeFlags_SpanAvailWidth)) {
                render_fonts();
                ImGui::TreePop();
            }
        }

        if (ImGui::TreeNodeEx("Keys", ImGuiTreeNodeFlags_SpanAvailWidth)) {
            render_keys();
            ImGui::TreePop();
        }

        if (ImGui::TreeNodeEx("Vertices", ImGuiTreeNodeFlags_SpanAvailWidth)) {
            for (u32 i = 0; i < m_file.m_vertices.size(); ++i) {
                render_vertex(m_file.m_vertices[i], i);
            }

            ImGui::TreePop();
        }

        if (ImGui::TreeNodeEx("Unparsed Sections (raw hex)", ImGuiTreeNodeFlags_SpanAvailWidth)) {
            render_unparsed_sections();
            ImGui::TreePop();
        }
    }

    m_search_matches = matches_found;

    ImGui::PopItemWidth();
}

void GUIEditor::render_header() {
    const GUIHeader& h = m_file.m_header;

    ImGui::RichText("<C FFC6913F>File:</C> {}", m_file_path.string());
    ImGui::NewLine();

    // Every header field as a plain edit box (writable ones are tracked for the save dialog)
    ImGui::PushItemWidth(240.0f);

    const auto edit_header_u32 = [this](const char* label, const char* path, u64 offset, u32& value) {
        u32 v = value;

        if (ImGui::InputScalar(label, ImGuiDataType_U32, &v)) {
            m_file.record_u32(path, offset, value, v);
            value = v;
        }
    };

    edit_header_u32("viewSize_Width",   "Header.viewSize_Width",   0x98, m_file.m_header.viewSize_Width);
    edit_header_u32("viewSize_Height",  "Header.viewSize_Height",  0x9C, m_file.m_header.viewSize_Height);
    edit_header_u32("attr",             "Header.attr",             0x0C, m_file.m_header.attr);
    edit_header_u32("instanceID",       "Header.instanceID",       0x18, m_file.m_header.instanceID);
    edit_header_u32("flowID",           "Header.flowID",           0x1C, m_file.m_header.flowID);
    edit_header_u32("variableID",       "Header.variableID",       0x20, m_file.m_header.variableID);
    edit_header_u32("startInstanceIndex", "Header.startInstanceIndex", 0x24, m_file.m_header.startInstanceIndex);
    edit_header_u32("optionBitFlag",    "Header.optionBitFlag",    0x94, m_file.m_header.optionBitFlag);

    ImGui::PopItemWidth();
    ImGui::NewLine();

    ImGui::RichText("<C FFC6913F>Magic:</C> {}", std::string(h.fileType, 4));
    ImGui::RichText("<C FFC6913F>GUI Version:</C> {:#x}", static_cast<u32>(h.guiVersion));
    ImGui::RichText("<C FFC6913F>File Size:</C> {}", static_cast<u32>(h.fileSize));
    ImGui::RichText("<C FFC6913F>Attr:</C> {:#x}", static_cast<u32>(h.attr));
    ImGui::RichText("<C FFC6913F>Revision Date:</C> {}", static_cast<long long>(h.revisionDate));
    ImGui::RichText("<C FFC6913F>Instance ID:</C> {}", static_cast<u32>(h.instanceID));
    ImGui::RichText("<C FFC6913F>Flow ID:</C> {}", static_cast<u32>(h.flowID));
    ImGui::RichText("<C FFC6913F>Variable ID:</C> {}", static_cast<u32>(h.variableID));
    ImGui::RichText("<C FFC6913F>Start Instance Index:</C> {}", static_cast<u32>(h.startInstanceIndex));
    ImGui::RichText("<C FFC6913F>Option Bit Flag:</C> {:#x}", static_cast<u32>(h.optionBitFlag));
    ImGui::RichText("<C FFC6913F>View Size:</C> {} x {}", static_cast<u32>(h.viewSize_Width), static_cast<u32>(h.viewSize_Height));
    ImGui::RichText("<C FFC6913F>Vertex Buffer Size:</C> {}", static_cast<u32>(h.vertexBufferSize));
    ImGui::RichText("<C FFC6913F>Start Flow Index:</C> {}", static_cast<u64>(h.startFlowIndex));
    ImGui::RichText("<C FFC6913F>Instance Param Entry Start Index:</C> {}", static_cast<u64>(h.instanceParamEntryStartIndex));

    if (ImGui::TreeNodeEx("Counts", ImGuiTreeNodeFlags_SpanAvailWidth)) {
        ImGui::RichText("animationNum {}", static_cast<u32>(h.animationNum));
        ImGui::RichText("sequenceNum {}", static_cast<u32>(h.sequenceNum));
        ImGui::RichText("objectNum {}", static_cast<u32>(h.objectNum));
        ImGui::RichText("objSequenceNum {}", static_cast<u32>(h.objSequenceNum));
        ImGui::RichText("initParamNum {}", static_cast<u32>(h.initParamNum));
        ImGui::RichText("paramNum {}", static_cast<u32>(h.paramNum));
        ImGui::RichText("keyNum {}", static_cast<u32>(h.keyNum));
        ImGui::RichText("instanceNum {}", static_cast<u32>(h.instanceNum));
        ImGui::RichText("flowNum {}", static_cast<u32>(h.flowNum));
        ImGui::RichText("flowProcessNum {}", static_cast<u32>(h.flowProcessNum));
        ImGui::RichText("flowInputNum {}", static_cast<u32>(h.flowInputNum));
        ImGui::RichText("flowSwitchNum {}", static_cast<u32>(h.flowSwitchNum));
        ImGui::RichText("switchOperatorNum {}", static_cast<u32>(h.switchOperatorNum));
        ImGui::RichText("switchConditionNum {}", static_cast<u32>(h.switchConditionNum));
        ImGui::RichText("variableNum {}", static_cast<u32>(h.variableNum));
        ImGui::RichText("textureNum {}", static_cast<u32>(h.textureNum));
        ImGui::RichText("fontNum {}", static_cast<u32>(h.fontNum));
        ImGui::RichText("fontFilterNum {}", static_cast<u32>(h.fontFilterNum));
        ImGui::RichText("messageNum {}", static_cast<u32>(h.messageNum));
        ImGui::RichText("guiResourceNum {}", static_cast<u32>(h.guiResourceNum));
        ImGui::RichText("generalResourceNum {}", static_cast<u32>(h.generalResourceNum));
        ImGui::TreePop();
    }

    if (ImGui::TreeNodeEx("Section Offsets", ImGuiTreeNodeFlags_SpanAvailWidth)) {
        ImGui::RichText("animationOffset {:#x}", static_cast<u64>(h.animationOffset));
        ImGui::RichText("sequenceOffset {:#x}", static_cast<u64>(h.sequenceOffset));
        ImGui::RichText("objectOffset {:#x}", static_cast<u64>(h.objectOffset));
        ImGui::RichText("objSequenceOffset {:#x}", static_cast<u64>(h.objSequenceOffset));
        ImGui::RichText("initParamOffset {:#x}", static_cast<u64>(h.initParamOffset));
        ImGui::RichText("paramOffset {:#x}", static_cast<u64>(h.paramOffset));
        ImGui::RichText("instanceOffset {:#x}", static_cast<u64>(h.instanceOffset));
        ImGui::RichText("flowOffset {:#x}", static_cast<u64>(h.flowOffset));
        ImGui::RichText("flowProcessOffset {:#x}", static_cast<u64>(h.flowProcessOffset));
        ImGui::RichText("flowSwitchOffset {:#x}", static_cast<u64>(h.flowSwitchOffset));
        ImGui::RichText("switchOperatorOffset {:#x}", static_cast<u64>(h.switchOperatorOffset));
        ImGui::RichText("switchConditionOffset {:#x}", static_cast<u64>(h.switchConditionOffset));
        ImGui::RichText("variableOffset {:#x}", static_cast<u64>(h.variableOffset));
        ImGui::RichText("textureOffset {:#x}", static_cast<u64>(h.textureOffset));
        ImGui::RichText("fontOffset {:#x}", static_cast<u64>(h.fontOffset));
        ImGui::RichText("fontFilterOffset {:#x}", static_cast<u64>(h.fontFilterOffset));
        ImGui::RichText("messageOffset {:#x}", static_cast<u64>(h.messageOffset));
        ImGui::RichText("guiResourceOffset {:#x}", static_cast<u64>(h.guiResourceOffset));
        ImGui::RichText("generalResourceOffset {:#x}", static_cast<u64>(h.generalResourceOffset));
        ImGui::RichText("stringOffset {:#x}", static_cast<u64>(h.stringOffset));
        ImGui::RichText("keyOffset {:#x}", static_cast<u64>(h.keyOffset));
        ImGui::RichText("keyValue8Offset {:#x}", static_cast<u64>(h.keyValue8Offset));
        ImGui::RichText("keyValue32Offset {:#x}", static_cast<u64>(h.keyValue32Offset));
        ImGui::RichText("keyValue128Offset {:#x}", static_cast<u64>(h.keyValue128Offset));
        ImGui::RichText("extendDataOffset {:#x}", static_cast<u64>(h.extendDataOffset));
        ImGui::RichText("vertexOffset {:#x}", static_cast<u64>(h.vertexOffset));
        ImGui::TreePop();
    }
}

void GUIEditor::render_flow(GUIFlow& flow, u32 index) {
    ImGui::PushID(static_cast<int>(index));

    ImGui::Text("Type: %s   Name: %s",
        std::string(enum_to_string(flow.Type)).c_str(), flow.Name.c_str());

    u32 id = flow.ID;
    if (ImGui::InputScalar("ID", ImGuiDataType_U32, &id)) {
        m_file.record_u32(fmt::format("Flows[{}].ID", index), m_file.flow_offset(index), flow.ID, id);
        flow.ID = id;
    }

    u32 attr = flow.Attr;
    if (ImGui::InputScalar("Attr", ImGuiDataType_U32, &attr)) {
        m_file.record_u32(fmt::format("Flows[{}].Attr", index), m_file.flow_offset(index) + 8, flow.Attr, attr);
        flow.Attr = attr;
    }

    u32 process_index = flow.FlowProcessIndex;
    if (ImGui::InputScalar("FlowProcessIndex", ImGuiDataType_U32, &process_index)) {
        m_file.record_u32(fmt::format("Flows[{}].FlowProcessIndex", index),
            m_file.flow_offset(index) + 24, flow.FlowProcessIndex, process_index, 1);
        flow.FlowProcessIndex = process_index;
    }

    ImGui::PopID();
}

void GUIEditor::render_flow_process(GUIFlowProcess& process, u32 index) {
    ImGui::PushID(static_cast<int>(index));

    ImGui::Text("EndCondition: %s", std::string(enum_to_string(process.EndCondition)).c_str());

    const u64 base = m_file.flow_process_offset(index);

    // LoopData is a union: expose its raw value
    u32 loop = process.LoopData.Raw;
    if (ImGui::InputScalar("LoopData (raw)", ImGuiDataType_U32, &loop)) {
        m_file.record_u32(fmt::format("FlowProcesses[{}].LoopData", index), base, process.LoopData.Raw, loop, 1);
        process.LoopData.Raw = loop;
    }

    u32* const values[] = {
        &process.TotalFrameCount, &process.ParamNum, &process.ParamIndex, &process.ActionNum,
        &process.EndConditionParam, &process.FlowIndex, &process.ActionIndex
    };
    const u64 offsets[] = { 4, 8, 12, 16, 24, 32, 40 };
    const char* names[] = {
        "TotalFrameCount", "ParamNum", "ParamIndex", "ActionNum",
        "EndConditionParam", "FlowIndex", "ActionIndex"
    };

    for (int i = 0; i < 7; ++i) {
        u32 value = *values[i];

        if (ImGui::InputScalar(names[i], ImGuiDataType_U32, &value)) {
            m_file.record_u32(fmt::format("FlowProcesses[{}].{}", index, names[i]),
                base + offsets[i], *values[i], value, 1);
            *values[i] = value;
        }
    }

    ImGui::PopID();
}

void GUIEditor::render_fonts() {
    for (u32 i = 0; i < m_file.m_fonts.size(); ++i) {
        auto& font = m_file.m_fonts[i];
        ImGui::PushID(static_cast<int>(i));

        u32 id = font.ID;
        if (ImGui::InputScalar("ID", ImGuiDataType_U32, &id)) {
            m_file.record_u32(fmt::format("Fonts[{}].ID", i), m_file.font_offset(i), font.ID, id);
            font.ID = id;
        }

        ImGui::Text("Path: %s  (string editing is not supported yet)", font.Path.c_str());
        ImGui::PopID();
    }
}

void GUIEditor::render_keys() {
    for (u32 i = 0; i < m_file.m_keys.size(); ++i) {
        auto& key = m_file.m_keys[i];
        ImGui::PushID(static_cast<int>(i));

        u32 data = key.Data.Full;
        if (ImGui::InputScalar("Data (frame|mode)", ImGuiDataType_U32, &data)) {
            m_file.record_u32(fmt::format("Keys[{}].Data", i), m_file.key_offset(i), key.Data.Full, data, 1);
            key.Data.Full = data;
        }

        u32 curve_offset = key.CurveOffset;
        if (ImGui::InputScalar("CurveOffset", ImGuiDataType_U32, &curve_offset)) {
            m_file.record_u32(fmt::format("Keys[{}].CurveOffset", i),
                m_file.key_offset(i) + 4, key.CurveOffset, curve_offset, 2);
            key.CurveOffset = curve_offset;
        }

        render_key(key);
        ImGui::PopID();
    }
}

void GUIEditor::render_vertex(GUIVertex& vertex, u32 index) {
    ImGui::PushID(static_cast<int>(index));

    float* v = reinterpret_cast<float*>(&vertex.V);
    float* uv = reinterpret_cast<float*>(&vertex.UV);

    const u64 base = m_file.vertex_offset(index);

    for (int c = 0; c < 4; ++c) {
        ImGui::PushID(c);
        float value = v[c];

        if (ImGui::InputFloat("v", &value)) {
            m_file.record_f32(fmt::format("Vertices[{}].V{}", index, c), base + c * 4, v[c], value);
            v[c] = value;
        }

        ImGui::PopID();

        if (c < 3) {
            ImGui::SameLine();
        }
    }

    for (int c = 0; c < 2; ++c) {
        ImGui::PushID(100 + c);
        float value = uv[c];

        if (ImGui::InputFloat("uv", &value)) {
            m_file.record_f32(fmt::format("Vertices[{}].UV{}", index, c), base + 16 + c * 4, uv[c], value);
            uv[c] = value;
        }

        ImGui::PopID();

        if (c == 0) {
            ImGui::SameLine();
        }
    }

    ImGui::PopID();
}

void GUIEditor::render_unparsed_sections() const {
    const auto dump = [](const char* label, const std::vector<u8>& data) {
        if (data.empty()) {
            ImGui::RichText("<C FF808080>{}: empty</C>", label);
            return;
        }

        std::string hex;
        for (size_t i = 0; i < data.size() && i < 128; ++i) {
            hex += fmt::format("{:02X} ", data[i]);
        }

        if (data.size() > 128) {
            hex += fmt::format("... ({} bytes total)", data.size());
        }

        ImGui::RichText("<C FFC6913F>{}</C> ({} bytes, Unknown format)", label, data.size());
        ImGui::TextWrapped("%s", hex.c_str());
    };

    dump("flowInput", m_file.m_raw_flow_input);
    dump("flowSwitch", m_file.m_raw_flow_switch);
    dump("flowFunction", m_file.m_raw_flow_function);
    dump("action", m_file.m_raw_action);
    dump("inputCondition", m_file.m_raw_input_condition);
    dump("switchOperator", m_file.m_raw_switch_operator);
    dump("switchCondition", m_file.m_raw_switch_condition);
    dump("variable", m_file.m_raw_variable);
}
