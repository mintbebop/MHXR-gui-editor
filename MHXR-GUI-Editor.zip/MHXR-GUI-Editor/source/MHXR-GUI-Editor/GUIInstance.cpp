#include "pch.h"
#include "GUIInstance.h"

#include <fmt/format.h>

GUIInstance GUIInstance::read(BinaryReader& reader, const GUIHeader& header) {
	GUIInstance inst = {
		.ID = reader.read<u32>(),
		.Attr = reader.read<u32>(),
		.NextIndex = reader.read<s32>(),
		.ChildIndex = reader.read<s32>(),
		.InitParamNum = reader.read_skip<u32>(4),
		.Name = reader.abs_offset_read_string(header.stringOffset + reader.read_skip<u32>(4)),
		.Type = reader.read_skip<ObjectType>(4),
		.InitParamIndex = reader.read_skip<u32>(4),
		.ExtendDataOffset = reader.read_skip<s32>(4),
	};

    inst.ExtendData = GUIExtendData::read(reader, inst.Type, inst.ExtendDataOffset, header);

    return inst;
}

GUIInstance GUIInstance::read_mhxr(BinaryReader& reader, const GUIHeader& header) {
    // MHXR instance layout == MHW instance layout (56B)
    GUIInstance inst = {
        .ID = reader.read<u32>(),
        .Attr = reader.read<u32>(),
        .NextIndex = reader.read<s32>(),
        .ChildIndex = reader.read<s32>(),
        .InitParamNum = reader.read_skip<u32>(4),
        .Name = reader.abs_offset_read_string(header.stringOffset + reader.read_skip<u32>(4)),
        .Type = reader.read_skip<ObjectType>(4),
        .InitParamIndex = reader.read_skip<u32>(4),
        .ExtendDataOffset = reader.read_skip<s32>(4),
    };

    inst.ExtendData = GUIExtendData::read_mhxr(reader, inst.Type, inst.ExtendDataOffset, header);

    return inst;
}

GUIInstance GUIInstance::read_mhgu(BinaryReader& reader, const GUIHeaderMHGU& header) {
	GUIInstance inst = {
		.ID = reader.read<u32>(),
		.Attr = reader.read<u32>(),
		.NextIndex = reader.read<s32>(),
		.ChildIndex = reader.read<s32>(),
		.InitParamNum = reader.read<u32>(),
		.Name = reader.abs_offset_read_string(header.stringOffset + reader.read<u32>()),
		.Type = reader.read<ObjectType>(),
		.InitParamIndex = reader.read<u32>(),
		.ExtendDataOffset = reader.read<s32>(),
	};

	inst.ExtendData = GUIExtendData::read_mhgu(reader, inst.Type, inst.ExtendDataOffset, header);

	return inst;
}

void GUIInstance::write(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
	writer.write(ID);
    writer.write(Attr);
    writer.write(NextIndex);
    writer.write(ChildIndex);
    writer.write(InitParamNum);
	writer.write<u32>(0);
    writer.write(buffer.append_no_duplicate(Name));
    writer.write(static_cast<u64>(Type));
    writer.write<u64>(InitParamIndex);

    if (ExtendDataOffset != -1) {
        writer.write(kv_buffers.ExtendData.size());
        ExtendData.write(kv_buffers, Type);
    } else {
        writer.write_tuple<s32, s32>({ -1, 0 });
    }

}

void GUIInstance::write_mhxr(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
    // Mirror of read_mhxr: 56B, every field occupies an 8 byte slot (value in the low 32 bits)
    writer.write(ID);
    writer.write(Attr);
    writer.write(NextIndex);
    writer.write(ChildIndex);
    writer.write(InitParamNum);
    writer.write<u32>(0);
    writer.write(static_cast<u32>(buffer.append_no_duplicate(Name)));
    writer.write<u32>(0);
    writer.write(static_cast<u32>(Type));
    writer.write<u32>(0);
    writer.write(InitParamIndex);
    writer.write<u32>(0);

    if (ExtendDataOffset != -1) {
        writer.write(static_cast<s32>(kv_buffers.ExtendData.size()));
        writer.write<u32>(0);
        ExtendData.write_mhxr(kv_buffers, Type);
    } else {
        writer.write<s32>(-1);
        writer.write<u32>(0);
    }
}

void GUIInstance::write_mhgu(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
    writer.write(ID);
    writer.write(Attr);
    writer.write(NextIndex);
    writer.write(ChildIndex);
    writer.write(InitParamNum);
    writer.write<u32>(0);
    writer.write((u32)buffer.append_no_duplicate(Name));
    writer.write(Type);
    writer.write(InitParamIndex);

    if (ExtendDataOffset != -1) {
        writer.write((u32)kv_buffers.ExtendData.size());
        ExtendData.write_mhgu(kv_buffers, Type);
    } else {
        writer.write<s32>(-1);
    }
}

std::string GUIInstance::get_preview(u32 index) const {
    if (index == -1) {
        return fmt::format("Instance<<C FFA3D7B8>{}</C>>: <C FFB0C94E>{} </C><C FFFEDC9C>{}</C>", ID, enum_to_string(Type), Name);
    }

    return fmt::format("[<C FFA3D7B8>{}</C>] Instance<<C FFA3D7B8>{}</C>>: <C FFB0C94E>{} </C><C FFFEDC9C>{}</C>", index, ID, enum_to_string(Type), Name);
}
