#pragma once

#include "BinaryReader.h"
#include "BinaryWriter.h"
#include "StringBuffer.h"
#include "GUITypes.h"
#include "dti_types.h"

#include <string>
#include <array>

struct GUIVertex {
	static constexpr size_t size = sizeof(vector4);
	static constexpr size_t size_mhxr = 24; // x,y,z,w,u,v (6 floats)
	static GUIVertex read(BinaryReader& reader);
	static GUIVertex read_mhgu(BinaryReader& reader);
	static GUIVertex read_mhxr(BinaryReader& reader);

	void write(BinaryWriter& writer, StringBuffer& buffer) const;
    void write_mhgu(BinaryWriter& writer, StringBuffer& buffer) const;
	void write_mhxr(BinaryWriter& writer, StringBuffer& buffer) const;

	vector4 V;
	vector2 UV; // MHXR only
};

