#include "pch.h"
#include "GUISequence.h"

#include <fmt/format.h>

GUISequence GUISequence::read(BinaryReader& reader, std::streamoff text_offset) {
	return {
		.ID = reader.read<u32>(),
		.FrameCount = reader.read<u32>(),
		.Name = reader.abs_offset_read_string(text_offset + reader.read_skip<u32>(4))
	};
}

GUISequence GUISequence::read_mhgu(BinaryReader& reader, std::streamoff text_offset) {
	return {
		.ID = reader.read<u32>(),
		.FrameCount = reader.read<u32>(),
		.Name = reader.abs_offset_read_string(text_offset + reader.read<u32>())
	};
}

GUISequence GUISequence::read_mhxr(BinaryReader& reader) {
	return {
		.ID = reader.read_skip<u32>(4),
		.FrameCount = reader.read_skip<u32>(4)
	};
}

void GUISequence::write(BinaryWriter& writer, StringBuffer& buffer) const {
	writer.write(ID);
	writer.write(FrameCount);
    writer.write(buffer.append_no_duplicate(Name));
}

void GUISequence::write_mhxr(BinaryWriter& writer, StringBuffer& buffer) const {
	writer.write(ID);
	writer.write<u32>(0);
	writer.write(FrameCount);
	writer.write<u32>(0);
}

void GUISequence::write_mhgu(BinaryWriter& writer, StringBuffer& buffer) const {
    writer.write(ID);
    writer.write(FrameCount);
    writer.write((u32)buffer.append_no_duplicate(Name));
}

std::string GUISequence::get_preview(u32 index) const {
	if (index == 0xFFFFFFFF) {
		return fmt::format("Sequence<<C FFA3D7B8>{}</C>>: <C FFFEDC9C>{}</C> ({} Frames)", ID, Name, FrameCount);
	}

	return fmt::format("[<C FFA3D7B8>{}</C>] Sequence<<C FFA3D7B8>{}</C>>: <C FFFEDC9C>{}</C> ({} Frames)", index, ID, Name, FrameCount);
}
