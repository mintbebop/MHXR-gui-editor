#pragma once

// MHXR (Monster Hunter Explore) object / instance type table.
//
// Extracted from libMHS.so (.rodata class names) and verified against real .gui files.
//
// Type IDs stored in .gui files are:
//     CRC32(className)  -- standard reflected CRC32 table, init = 0xFFFFFFFF, NO final xor
//     then & 0x7FFFFFFF (top bit cleared)
//
// Verified pairs:
//     "cGUIInstAnimation" -> 0x1DAA79DB
//     "cGUIInstMHiNull"   -> 0x9323F18A -> stored as 0x1323F18A
//     "cGUIInstNull"      -> 0xC19B2827 -> stored as 0x419B2827
//
// Verification: all 25 instances of title_01.gui resolve to a name in this table.

#include "GUITypes.h"

inline const std::map<ObjectType, const char*> ObjectTypeNamesMHXR = {
    { (ObjectType)0x114D81F2u, "cGUIAccumurateRewardBanner" },
    { (ObjectType)0x76618B39u, "cGUIActivityMessage" },
    { (ObjectType)0x70695391u, "cGUIArtifactThumbnail" },
    { (ObjectType)0x405EB38Eu, "cGUICache" },
    { (ObjectType)0x29C0C372u, "cGUICmnArrow" },
    { (ObjectType)0x0C780EFAu, "cGUICmnNyankenDisruptMapChip" },
    { (ObjectType)0x791BAC22u, "cGUICmnNyankenTreasureReward" },
    { (ObjectType)0x05BB81E9u, "cGUICmnOtomoBanner" },
    { (ObjectType)0x5FEAD73Au, "cGUICmnOtomoSyosai" },
    { (ObjectType)0x6A01DA53u, "cGUICmnOtomoThumbnail" },
    { (ObjectType)0x70C0074Bu, "cGUICmnSpecialThumbnail" },
    { (ObjectType)0x18EB2DE8u, "cGUIEquipBanner" },
    { (ObjectType)0x287D59EAu, "cGUIEventBanner" },
    { (ObjectType)0x4DA71809u, "cGUIEventEternityNodeBanner" },
    { (ObjectType)0x5BD2DA18u, "cGUIEventNodeBanner" },
    { (ObjectType)0x3BCF639Bu, "cGUIEventQuestOutAdminBanner" },
    { (ObjectType)0x134935E4u, "cGUIFontFilter" },
    { (ObjectType)0x6DF3AB1Eu, "cGUIFontFilterBorder" },
    { (ObjectType)0x77214222u, "cGUIFontFilterGradationOverlay" },
    { (ObjectType)0x3D35D49Au, "cGUIFontFilterShading" },
    { (ObjectType)0x5F704244u, "cGUIFontFilterShadow" },
    { (ObjectType)0x5863E885u, "cGUIFontFilterTextureBlend" },
    { (ObjectType)0x4DE6D8D3u, "cGUIForestFuelBar" },
    { (ObjectType)0x314746FBu, "cGUIForestItemBanner" },
    { (ObjectType)0x7C431E8Au, "cGUIInstAnimControl" },
    { (ObjectType)0x723D0214u, "cGUIInstAnimVariable" },
    { (ObjectType)0x1DAA79DBu, "cGUIInstAnimation" },
    { (ObjectType)0x1323F18Au, "cGUIInstMHiNull" },
    { (ObjectType)0x010722FEu, "cGUIInstMessage" },
    { (ObjectType)0x419B2827u, "cGUIInstNull" },
    { (ObjectType)0x72A42D33u, "cGUIInstRoot" },
    { (ObjectType)0x70357604u, "cGUIInstScissorMask" },
    { (ObjectType)0x5FDB73AFu, "cGUIInstText" },
    { (ObjectType)0x57FD7FB5u, "cGUIInstance" },
    { (ObjectType)0x28787AD6u, "cGUIItemThumbnail" },
    { (ObjectType)0x1132951Eu, "cGUIKaritomoSyosai" },
    { (ObjectType)0x4A232EA7u, "cGUIMenuScroll" },
    { (ObjectType)0x6DC2BF5Bu, "cGUIMessageAnalyzer" },
    { (ObjectType)0x3036E975u, "cGUIMessageErrorInfo" },
    { (ObjectType)0x75072A46u, "cGUINyankenIcon" },
    { (ObjectType)0x2F6E2D38u, "cGUINyankenRewardBanner" },
    { (ObjectType)0x14F76F6Eu, "cGUIObj2D" },
    { (ObjectType)0x2787DB24u, "cGUIObjChildAnimationRoot" },
    { (ObjectType)0x0753E61Au, "cGUIObjColorAdjust" },
    { (ObjectType)0x2FB82EAEu, "cGUIObjMessage" },
    { (ObjectType)0x2F7F374Cu, "cGUIObjNull" },
    { (ObjectType)0x5EA13FC3u, "cGUIObjPolygon" },
    { (ObjectType)0x1C403258u, "cGUIObjRoot" },
    { (ObjectType)0x0DA93F7Au, "cGUIObjScissorMask" },
    { (ObjectType)0x313F6CC4u, "cGUIObjText" },
    { (ObjectType)0x1B6313A3u, "cGUIObjTexture" },
    { (ObjectType)0x4F7228FCu, "cGUIObjTextureSet" },
    { (ObjectType)0x63BF6258u, "cGUIObjUVRotate" },
    { (ObjectType)0x4EC08445u, "cGUIObject" },
    { (ObjectType)0x4CB645C7u, "cGUIPartnerThumbnail" },
    { (ObjectType)0x3ADB715Au, "cGUIQuestBanner" },
    { (ObjectType)0x1517C5ABu, "cGUIRewardItemBanner" },
    { (ObjectType)0x13B92A0Fu, "cGUIRoomBanner" },
    { (ObjectType)0x1D3A0047u, "cGUISequenceCtrl" },
    { (ObjectType)0x636EECEEu, "cGUISideScroll" },
    { (ObjectType)0x13F674B5u, "cGUISpecialItemBanner" },
    { (ObjectType)0x3E827320u, "cGUIStampThumbnail" },
    { (ObjectType)0x046DBA1Fu, "cGUISubtargetTab" },
    { (ObjectType)0x087DBAE4u, "cGUISyougouIcon" },
    { (ObjectType)0x73D67E48u, "cGUIThumbnailBase" },
    { (ObjectType)0x6E7385EEu, "cGUIUserTitleCache" },
    { (ObjectType)0x3FBDE402u, "cGUIVarFloat" },
    { (ObjectType)0x3CED137Fu, "cGUIVarInt" },
    { (ObjectType)0x598049E6u, "cGUIVariable" },
};

// MHXR files store type IDs with the top bit cleared, so look them up in the MHXR table first.
[[nodiscard]] inline const char* object_type_name(ObjectType type, bool is_mhxr) {
    if (is_mhxr) {
        if (const auto it = ObjectTypeNamesMHXR.find(type); it != ObjectTypeNamesMHXR.end()) {
            return it->second;
        }
    }

    if (const auto it = ObjectTypeNames.find(type); it != ObjectTypeNames.end()) {
        return it->second;
    }

    return "Unknown";
}
