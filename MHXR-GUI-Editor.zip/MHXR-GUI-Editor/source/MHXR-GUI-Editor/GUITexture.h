#pragma once

#include "BinaryReader.h"
#include "BinaryWriter.h"
#include "StringBuffer.h"
#include "GUITypes.h"
#include "I18n.h"
#include "dti_types.h"
#include "Texture.h"

#include <fmt/format.h>
#include <string>

// Why a texture could not be loaded. Only the reason and its parameter are stored, the
// readable message is built while rendering so switching the UI language takes effect
// without reloading the file.
enum class TextureLoadError {
    None,
    ArcfsNotSet,
    EmptyPath,
    DdsMissing,     // .tex was found but not converted to .dds yet
    NotFound,       // neither .dds nor .tex exists
    DecodeFailed,
    DecodeException,
    DecodeUnknown
};


struct GUITexture {
	static constexpr size_t size = 64;
	static constexpr size_t size_mhxr = 72;
	static GUITexture read(BinaryReader& reader, const GUIHeader& header);
	static GUITexture read_mhgu(BinaryReader& reader, const GUIHeaderMHGU& header);
	static GUITexture read_mhxr(BinaryReader& reader, const GUIHeader& header);

	void write(BinaryWriter& writer, StringBuffer& buffer) const;
    void write_mhgu(BinaryWriter& writer, StringBuffer& buffer) const;
	void write_mhxr(BinaryWriter& writer, StringBuffer& buffer) const;

	u32 ID;
	union {
		struct {
			u32 RenderTargetType : 2;
			u32 Resize : 1;
			u32 : 29;
		};

		u32 Raw;
	} Meta;

	u16 Left;
	u16 Top;
	u16 Width;
	u16 Height;
	float4 Clamp;
	vector2 InvSize;
	std::string Path;
	std::string Name;

	// Full path this texture was actually resolved to on disk.
	// When nothing was found it holds the path that was searched for.
	std::string ResolvedPath;

	std::array<u8, 24> TailMHXR{}; // MHXR only: 24 unknown trailing bytes

    TextureLoadError ErrorCode = TextureLoadError::None;

    // What the message refers to: a file path, or the exception text
    std::string ErrorParam;

    Texture RenderTexture;
};

[[nodiscard]] inline std::string texture_error_text(const GUITexture& tex) {
    switch (tex.ErrorCode) {
    case TextureLoadError::None:            return {};
    case TextureLoadError::ArcfsNotSet:     return I18n::T("error.texture.arcfs_not_set");
    case TextureLoadError::EmptyPath:       return I18n::T("error.texture.empty_path");
    case TextureLoadError::DdsMissing:      return fmt::format("{} {}", I18n::T("error.texture.dds_missing"), tex.ErrorParam);
    case TextureLoadError::NotFound:        return fmt::format("{} {}", I18n::T("error.texture.not_found"), tex.ErrorParam);
    case TextureLoadError::DecodeFailed:    return fmt::format("{} {}", I18n::T("error.texture.decode_failed"), tex.ErrorParam);
    case TextureLoadError::DecodeException: return fmt::format("{} {}", I18n::T("error.texture.decode_exception"), tex.ErrorParam);
    case TextureLoadError::DecodeUnknown:   return fmt::format("{} {}", I18n::T("error.texture.decode_unknown"), tex.ErrorParam);
    }

    return {};
}

