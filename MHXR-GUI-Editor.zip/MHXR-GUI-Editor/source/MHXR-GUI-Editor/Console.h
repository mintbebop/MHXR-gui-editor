#pragma once

#include <spdlog/spdlog.h>

#include <memory>
#include <string>

class Console {
public:
    static const std::shared_ptr<Console>& get();

    // allocate_console: also open a visible console window. Release builds pass false
    // so the editor stays a pure GUI app and only writes the log file.
    void initialize(bool allocate_console);
    void shutdown();

    [[nodiscard]] auto get_logger() const { return m_logger; }

    // Absolute path of the log file, shown to the user when something goes wrong
    [[nodiscard]] const std::string& get_log_path() const { return m_log_path; }

private:
    static std::shared_ptr<Console> m_instance;

    std::shared_ptr<spdlog::logger> m_logger;
    std::string m_log_path;
};

