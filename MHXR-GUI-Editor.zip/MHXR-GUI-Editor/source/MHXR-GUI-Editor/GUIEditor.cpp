#include "pch.h"
#include "GUIEditor.h"
#include "HrException.h"
#include "RichText.h"
#include "GroupPanel.h"
#include "CurveEditor.h"
#include "App.h"
#include "IconFontAwesome.h"
#include "crc32.h"
#include "Console.h"

#include "imgui-notify/tahoma.h"

#include <fmt/format.h>
#include <imgui_internal.h>
#include <imgui_stdlib.h>
#include <imgui.h>
#include <ShObjIdl.h>
#include <wrl.h>
#include <ranges>
#include <nlohmann/json.hpp>

GUIEditor::GUIEditor(Editor* owner, const std::filesystem::path& file) : m_owner(owner) {
    m_app = m_owner->get_app();

    BinaryReader reader(file);
    m_file.load_from(reader);
    m_file_path = file;

    const auto& settings = owner->get_settings();
    // MHXR textures are resolved from ArcfsPath only, so ArcfsPath must also enable resource loading
    if (!settings.ChunkPath.empty() || !settings.NativePath.empty() || !settings.ArcfsPath.empty()) {
        m_file.load_resources(
            settings.ChunkPath,
            settings.NativePath,
            settings.ArcfsPath,
            m_app->get_device().Get(),
            m_app->get_context().Get()
        );
    }

    m_file.run_data_usage_analysis(true);

    update_indices();
    collect_file_glyphs();
}

void GUIEditor::render(u32 dockspace_id) {
    if (!m_generic_popup_queue.empty()) {
        ImGui::PushID("GenericPopupQueue");

        auto& popup = m_generic_popup_queue.front();
        if (!ImGui::IsPopupOpen(popup.Title.c_str())) {
            ImGui::OpenPopup(popup.Title.c_str());
        }

        if (ImGui::BeginPopupModal(popup.Title.c_str(), nullptr, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_AlwaysAutoResize)) {
            if (popup.DrawCallback(popup.UserData)) {
                m_generic_popup_queue.pop();
            }

            ImGui::EndPopup();
        }

        ImGui::PopID();
    }

    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 5.f);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(43.f / 255.f, 43.f / 255.f, 43.f / 255.f, 100.f / 255.f));
    ImGui::RenderNotifications();
    ImGui::PopStyleVar(1);
    ImGui::PopStyleColor(1);
}

void GUIEditor::save_file() {
    if (m_file_path.empty()) {
        return;
    }

    const auto& settings = m_owner->get_settings();

    // Keep a backup of the original file before writing
    if (settings.AutoBackup && std::filesystem::exists(m_file_path)) {
        std::filesystem::path backup = m_file_path;
        backup += ".bak";
        std::filesystem::copy_file(m_file_path, backup, std::filesystem::copy_options::overwrite_existing);
    }

    if (!write_file_safely(m_file_path)) {
        return;
    }

    // Verify the written file by parsing it straight back
    bool verified = false;
    std::string verify_error;

    try {
        BinaryReader check(m_file_path);
        GUIFile reloaded {};
        reloaded.load_from(check);
        verified = true;
    } catch (const std::exception& e) {
        verify_error = e.what();
    } catch (...) {
        verify_error = "unknown exception";
    }

    m_file.clear_changes();

    ImGuiToast toast(verified ? ImGuiToastType_Success : ImGuiToastType_Error);
    toast.set_title(verified ? I18n::T("toast.saved") : I18n::T("toast.save_failed"));
    toast.set_type(verified ? ImGuiToastType_Success : ImGuiToastType_Error);

    if (verified) {
        toast.set_content("%s", fmt::format("{}\n{} {}",
            m_file_path.string(),
            I18n::T("toast.saved_detail"),
            I18n::T("toast.byte_identical_note")).c_str());
    } else {
        toast.set_content("%s", fmt::format("{}\n{}: {}",
            m_file_path.string(),
            I18n::T("toast.reparse_failed"),
            verify_error).c_str());
    }

    ImGui::InsertNotification(toast);
}

void GUIEditor::save_file_as(const std::filesystem::path& path) {
    if (!write_file_safely(path)) {
        return;
    }

    m_file_path = path;

    ImGuiToast toast(ImGuiToastType_Success);
    toast.set_title(I18n::T("toast.saved"));
    toast.set_type(ImGuiToastType_Success);
    toast.set_content(I18n::T("toast.saved_as"), m_file_path.string().c_str());
    ImGui::InsertNotification(toast);
}

bool GUIEditor::write_file_safely(const std::filesystem::path& path) {
    // Write next to the target first: save_to can refuse (structural changes, unknown
    // version) and that must never leave a truncated file behind.
    const auto temp_path = path.string() + ".tmp";
    bool written = false;

    {
        BinaryWriter writer(temp_path);
        written = m_file.save_to(writer, m_owner->get_settings());
    }

    if (!written) {
        std::filesystem::remove(temp_path);
        spdlog::error("Save aborted, {} was left untouched", path.string());

        ImGuiToast toast(ImGuiToastType_Error);
        toast.set_title(I18n::T("toast.save_failed"));
        toast.set_type(ImGuiToastType_Error);
        toast.set_content("%s", I18n::T("toast.save_aborted"));
        ImGui::InsertNotification(toast);

        return false;
    }

    std::filesystem::copy_file(temp_path, path, std::filesystem::copy_options::overwrite_existing);
    std::filesystem::remove(temp_path);

    return true;
}

void GUIEditor::render_object_editor() {
    if (m_selected_object == -1) {
        return;
    }

    if (!ImGui::Begin(I18n::T("window.object_editor"), &m_object_editor_visible)) {
        return;
    }

    ImGui::End();
}

ParamValidationResult GUIEditor::is_valid_param(ParamType type, const std::string& name, ObjectType source_object) const {
    if (source_object == ObjectType::None) {
        return { .CorrectType = type };
    }

    bool invalid_name = false;
    bool invalid_type = false;
    ParamType correct_type = type;

    const auto& object_info_map = m_owner->get_object_info();
    const std::string source_object_name = enum_to_string(source_object);
    if (source_object != ObjectType::None) {
        if (object_info_map.contains(source_object_name)) {
            const auto& object_info = object_info_map.at(source_object_name);
            if (object_info->Params.contains(name)) {
                if (object_info->Params.at(name) != type) {
                    invalid_type = true;
                    correct_type = object_info->Params.at(name);
                }
            } else {
                invalid_name = true;
            }
        }
    }

    return { invalid_name, invalid_type, correct_type };
}

void GUIEditor::update_indices() {
    auto update_indices = [this](auto& list) {
        for (auto i = 0u; i < list.size(); ++i) {
            list[i].Index = i;
        }
    };

    update_indices(m_file.m_animations);
    update_indices(m_file.m_objects);
    update_indices(m_file.m_sequences);
    update_indices(m_file.m_obj_sequences);
    update_indices(m_file.m_init_params);
    update_indices(m_file.m_params);
    update_indices(m_file.m_instances);
    update_indices(m_file.m_keys);
}

void GUIEditor::collect_file_glyphs() {
    // Names and paths inside a file are arbitrary text, the fonts have to cover them
    const auto add = [this](const std::string& text) {
        m_owner->add_glyph_text(text);
    };

    // Shown as the tab title
    add(m_file_path.filename().string());

    for (const auto& anim : m_file.m_animations) {
        add(anim.Name);
    }

    for (const auto& seq : m_file.m_sequences) {
        add(seq.Name);
    }

    for (const auto& obj : m_file.m_objects) {
        add(obj.Name);
    }

    for (const auto& param : m_file.m_init_params) {
        add(param.Name);
    }

    for (const auto& param : m_file.m_params) {
        add(param.Name);
    }

    for (const auto& inst : m_file.m_instances) {
        add(inst.Name);
    }

    for (const auto& tex : m_file.m_textures) {
        add(tex.Name);
        add(tex.Path);
    }

    for (const auto& font : m_file.m_fonts) {
        add(font.Path);
    }
}

void GUIEditor::open_animation_editor() {
    if (m_animation_editor_first) {
        m_animation_editor_first = false;
    }
    
    m_animation_editor_visible = !m_animation_editor_visible;
}
