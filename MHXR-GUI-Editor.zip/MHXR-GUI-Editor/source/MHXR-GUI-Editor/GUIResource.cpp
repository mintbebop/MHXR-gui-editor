#include "pch.h"
#include "GUIResource.h"

GUIResource GUIResource::read(BinaryReader& reader, const GUIHeader& header) {
	GUIResource res{
		.ID = reader.read_skip<u32>(12)
	};

	const u32 offset = reader.read_skip<u32>(4);
	if (offset == -1) {
		res.Path = "";
    } else {
        res.Path = reader.abs_offset_read_string(header.stringOffset + offset);
    }

	return res;
}

GUIResource GUIResource::read_mhgu(BinaryReader& reader, const GUIHeaderMHGU& header) {
    reader.seek_relative(4); // Skip resource pointer

	GUIResource res{
		.ID = reader.read<u32>()
	};

	const u32 offset = reader.read<u32>();
	if (offset == -1) {
		res.Path = "";
	} else {
		res.Path = reader.abs_offset_read_string(header.stringOffset + offset);
	}

	return res;
}

GUIResource GUIResource::read_mhxr(BinaryReader& reader, const GUIHeader& header) {
    // 32B: [0:ID][4:pad 12B][16:PathOff][20:pad 12B]
    GUIResource res{ .ID = reader.read<u32>() };
    reader.seek_relative(12);
    const u32 offset = reader.read<u32>();
    reader.seek_relative(12);

    if (offset != 0xFFFFFFFF) {
        res.Path = reader.abs_offset_read_string(header.stringOffset + offset);
    }
    return res;
}

void GUIResource::write(BinaryWriter& writer, StringBuffer& buffer) const {
	writer.write(ID);
	writer.write<u32>(0);
	writer.write<u64>(0);
    writer.write(buffer.append_no_duplicate(Path));
}

void GUIResource::write_mhgu(BinaryWriter& writer, StringBuffer& buffer) const {
	writer.write<u32>(0);
    writer.write(ID);
	writer.write((u32)buffer.append_no_duplicate(Path));
}

void GUIResource::write_mhxr(BinaryWriter& writer, StringBuffer& buffer) const {
    writer.write(ID);
    writer.write<u64>(0);
    writer.write<u32>(0);
    writer.write(buffer.append_no_duplicate(Path));
    writer.write<u32>(0);
    writer.write<u64>(0);
}
