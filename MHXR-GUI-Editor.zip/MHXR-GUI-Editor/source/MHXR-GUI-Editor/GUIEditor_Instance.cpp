#include "pch.h"
#include "GUIEditor.h"
#include "MHXRObjectTypes.h"
#include "RichText.h"

#include <imgui_stdlib.h>


void GUIEditor::render_instance(GUIInstance& inst) {
    const u32 u32_step = 1;
    const u32 u32_fast_step = 10;

    // MHXR instance chains can be shared between chains or contain cycles -> never render one twice
    if (!m_visited_instances.insert(inst.Index).second) {
        return;
    }

    ImGui::PushID("Instance");
    ImGui::PushID(inst.Index);

    if (ImGui::RichTextTreeNode("Inst", inst.get_preview(inst.Index))) {
        u32 id = inst.ID;
        if (ImGui::InputScalar("ID", ImGuiDataType_U32, &id, &u32_step, &u32_fast_step)) {
            m_file.record_u32(fmt::format("Instances[{}].ID", inst.Index), m_file.instance_offset(inst.Index), inst.ID, id);
            inst.ID = id;
        }

        s32 child_index = inst.ChildIndex;
        if (ImGui::InputInt("Child Index", &child_index)) {
            m_file.record_u32(fmt::format("Instances[{}].ChildIndex", inst.Index),
                m_file.instance_offset(inst.Index) + 12, static_cast<u32>(inst.ChildIndex), static_cast<u32>(child_index), 2);
            inst.ChildIndex = child_index;
        }

        s32 next_index = inst.NextIndex;
        if (ImGui::InputInt("Next Index", &next_index)) {
            m_file.record_u32(fmt::format("Instances[{}].NextIndex", inst.Index),
                m_file.instance_offset(inst.Index) + 8, static_cast<u32>(inst.NextIndex), static_cast<u32>(next_index), 2);
            inst.NextIndex = next_index;
        }

        {
            std::string name = inst.Name;
            if (ImGui::InputText("Name", &name)) {
                FieldEdit::reject(fmt::format("Instances[{}].Name", inst.Index));
            }
        }
        const char* inst_type_name = object_type_name(inst.Type, m_file.is_mhxr());

        if (ImGui::BeginCombo("Type", inst_type_name)) {
            for (const auto& [type, name] : ObjectTypeNames) {
                if (ImGui::Selectable(name, inst.Type == type)) {
                    FieldEdit::reject(fmt::format("Instances[{}].Type", inst.Index));
                }
            }

            ImGui::EndCombo();
        }

        const s32 inst_count = static_cast<s32>(m_file.m_instances.size());

        if (inst.ChildIndex >= 0 && inst.ChildIndex < inst_count) {
            auto instance = &m_file.m_instances[inst.ChildIndex];
            render_instance(*instance);

            // Cap the iterations: a malformed or cyclic NextIndex chain would otherwise loop forever
            for (s32 guard = 0; instance->NextIndex >= 0 && instance->NextIndex < inst_count && guard < inst_count; ++guard) {
                instance = &m_file.m_instances[instance->NextIndex];
                render_instance(*instance);
            }
        }

        if (inst.InitParamNum > 0) {
            if (ImGui::TreeNodeEx("InitParams", ImGuiTreeNodeFlags_SpanAvailWidth)) {
                const u64 max = std::min(static_cast<u64>(inst.InitParamIndex + inst.InitParamNum), m_file.m_init_params.size());
                for (auto i = inst.InitParamIndex; i < max; ++i) {
                    render_init_param(m_file.m_init_params[i]);
                }

                if (inst.InitParamIndex + static_cast<u64>(inst.InitParamNum) > m_file.m_init_params.size()) {
                    ImGui::TextColored({ 1.0f, 1.0f, 0.2f, 1.0f }, "Warning: InitParamNum goes out of bounds!");
                }

                ImGui::TreePop();
            }
        }

        const auto param_idx = m_file.is_mhgu()
            ? m_file.m_header_mhgu.instExeParamOffset + inst.Index
            : m_file.m_header.instanceParamEntryStartIndex + inst.Index;
        if (param_idx < m_file.m_params.size()) {
            render_param(m_file.m_params[param_idx]);
        }

        ImGui::TreePop();
    }

    ImGui::PopID();
    ImGui::PopID();
}
