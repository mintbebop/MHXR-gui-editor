#include "pch.h"
#include "GUITexture.h"

GUITexture GUITexture::read(BinaryReader& reader, const GUIHeader& header) {
	GUITexture tex{
		.ID = reader.read<u32>(),
		.Meta = { .Raw = reader.read<u32>() },
		.Left = reader.read<u16>(),
		.Top = reader.read<u16>(),
		.Width = reader.read<u16>(),
		.Height = reader.read<u16>(),
		.Clamp = { reader.read<float>(), reader.read<float>(), reader.read<float>(), reader.read<float>() },
		.InvSize = reader.read_skip<vector2>(8)
	};

	const u32 path_offset = reader.read_skip<u32>(4);
    const u32 name_offset = reader.read_skip<u32>(4);

	if (path_offset != -1) {
        tex.Path = reader.abs_offset_read_string(header.stringOffset + path_offset);
    } else {
        tex.Path = "";
    }

    if (name_offset != -1) {
        tex.Name = reader.abs_offset_read_string(header.stringOffset + name_offset);
    } else {
        tex.Name = "";
    }

    return tex;
}

GUITexture GUITexture::read_mhgu(BinaryReader& reader, const GUIHeaderMHGU& header) {
    GUITexture tex{
        .ID = reader.read<u32>(),
        .Meta = { .Raw = reader.read<u32>() },
        .Left = reader.read<u16>(),
        .Top = reader.read<u16>(),
        .Width = reader.read<u16>(),
        .Height = reader.read<u16>(),
        .Clamp = { reader.read<float>(), reader.read<float>(), reader.read<float>(), reader.read<float>() },
        .InvSize = reader.read_skip<vector2>(4)
    };

    const u32 path_offset = reader.read<u32>();
    const u32 name_offset = reader.read<u32>();

    if (path_offset != -1) {
        tex.Path = reader.abs_offset_read_string(header.stringOffset + path_offset);
    } else {
        tex.Path = "";
    }

    if (name_offset != -1) {
        tex.Name = reader.abs_offset_read_string(header.stringOffset + name_offset);
    } else {
        tex.Name = "";
    }

    reader.seek_relative(12); // Skip 12 bytes (padding)

    return tex;
}

GUITexture GUITexture::read_mhxr(BinaryReader& reader, const GUIHeader& header) {
    // 72B: [0:ID][4:Meta][8:W][A:H][C:L][E:T][10:8B zero][18:InvSize]
    //      [20:PathOff][24:pad][28:NameOff][2C:pad][30:24B tail]
    GUITexture tex{
        .ID = reader.read<u32>(),
        .Meta = { .Raw = reader.read<u32>() },
        .Clamp = { 0.f, 0.f, 0.f, 0.f },
    };
    tex.Width = reader.read<u16>();
    tex.Height = reader.read<u16>();
    tex.Left = reader.read<u16>();
    tex.Top = reader.read<u16>();
    reader.seek_relative(8); // 8B zero / reserved
    tex.InvSize = { reader.read<f32>(), reader.read<f32>() };

    const u32 path_offset = reader.read<u32>();
    reader.seek_relative(4);
    const u32 name_offset = reader.read<u32>();
    reader.seek_relative(4); // pad @0x2C
    reader.read_bytes(tex.TailMHXR);

    if (path_offset != 0xFFFFFFFF) {
        tex.Path = reader.abs_offset_read_string(header.stringOffset + path_offset);
    }
    if (name_offset != 0xFFFFFFFF) {
        tex.Name = reader.abs_offset_read_string(header.stringOffset + name_offset);
    }

    return tex;
}

void GUITexture::write_mhxr(BinaryWriter& writer, StringBuffer& buffer) const {
    writer.write(ID);
    writer.write(Meta.Raw);
    writer.write(Width);
    writer.write(Height);
    writer.write(Left);
    writer.write(Top);
    writer.write<u64>(0); // 8B zero / reserved
    writer.write(InvSize);
    writer.write(static_cast<u32>(buffer.append_no_duplicate(Path)));
    writer.write<u32>(0);
    writer.write(static_cast<u32>(buffer.append_no_duplicate(Name)));
    writer.write<u32>(0); // pad @0x2C
    for (const auto b : TailMHXR) writer.write(b);
}

void GUITexture::write(BinaryWriter& writer, StringBuffer& buffer) const {
	writer.write(ID);
    writer.write(Meta.Raw);
    writer.write(Left);
    writer.write(Top);
    writer.write(Width);
    writer.write(Height);
    writer.write(Clamp[0]);
    writer.write(Clamp[1]);
    writer.write(Clamp[2]);
    writer.write(Clamp[3]);
    writer.write(InvSize);
    writer.write<u64>(0);
	writer.write(buffer.append_no_duplicate(Path));
	writer.write(buffer.append_no_duplicate(Name));
}

void GUITexture::write_mhgu(BinaryWriter& writer, StringBuffer& buffer) const {
    writer.write(ID);
    writer.write(Meta.Raw);
    writer.write(Left);
    writer.write(Top);
    writer.write(Width);
    writer.write(Height);
    writer.write(Clamp[0]);
    writer.write(Clamp[1]);
    writer.write(Clamp[2]);
    writer.write(Clamp[3]);
    writer.write(InvSize);
    writer.write<u32>(0);
    writer.write((u32)buffer.append_no_duplicate(Path));
    writer.write((u32)buffer.append_no_duplicate(Name));
}
