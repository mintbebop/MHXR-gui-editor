#include "pch.h"
#include "GUIExtendData.h"
#include "GUIVertex.h"


GUIExtendData GUIExtendData::read(BinaryReader& reader, ObjectType type, s64 offset, const GUIHeader& header) {
    if (offset == -1) {
        return {};
    }

    const auto old_pos = reader.tell();
    reader.seek_absolute(header.extendDataOffset + offset);

    GUIExtendData data{};

    switch (type) {
    case ObjectType::cGUIObjChildAnimationRoot:
        data.ChildAnimationRoot.GUIResourceId = reader.read<s32>();
        data.ChildAnimationRoot.AnimationId = reader.read<s32>();
        data.ChildAnimationRoot._pad = reader.read<u64>();
        break;
    case ObjectType::cGUIObjTextureSet:
        data.TextureSet.DataNum = reader.read<u32>();
        data.TextureSet.VertexIndex = reader.read<u32>();
        data.TextureSet.Data[0] = reader.read<float>();
        data.TextureSet.Data[1] = reader.read<float>();

        data.UVs.resize(data.TextureSet.DataNum);
        for (auto& uv : data.UVs) {
            uv = reader.read<rectf>();
        }
        break;
    default:
        data.FullData[0] = reader.read<u64>();
        data.FullData[1] = reader.read<u64>();
        break;
    }

    reader.seek_absolute(old_pos);

    return data;
}

GUIExtendData GUIExtendData::read_mhgu(BinaryReader& reader, ObjectType type, s64 offset, const GUIHeaderMHGU& header) {
    if (offset == -1) {
        return {};
    }

    const auto old_pos = reader.tell();
    reader.seek_absolute(header.extendDataOffset + offset);

    GUIExtendData data{};

    switch (type) {
    case ObjectType::cGUIObjChildAnimationRoot:
        data.ChildAnimationRoot.AnimationId = reader.read<s32>();
        break;
    case ObjectType::cGUIObjTextureSet:
        data.TextureSet.DataNum = reader.read<u32>();
        data.TextureSet.VertexIndex = reader.read<u32>();

        data.UVs.resize(data.TextureSet.DataNum);
        for (auto& uv : data.UVs) {
            uv = reader.read<rectf>();
        }
        break;
    default:
        data.FullData[0] = reader.read<u64>();
        data.FullData[1] = reader.read<u64>();
        break;
    }

    reader.seek_absolute(old_pos);

    return data;
}

GUIExtendData GUIExtendData::read_mhxr(BinaryReader& reader, ObjectType type, s64 offset, const GUIHeader& header) {
    if (offset == -1) {
        return {};
    }

    const auto old_pos = reader.tell();
    reader.seek_absolute(header.extendDataOffset + offset);

    GUIExtendData data{};

    switch (type) {
    case ObjectType::cGUIObjChildAnimationRoot:
        data.ChildAnimationRoot.GUIResourceId = reader.read<s32>();
        data.ChildAnimationRoot.AnimationId = reader.read<s32>();
        data.ChildAnimationRoot._pad = reader.read<u64>();
        break;
    case ObjectType::cGUIObjTextureSet: {
        // 32B: num u32, vertexIndex u32, rect 4f (x0,y0,x1,y1), pad u64
        data.TextureSet.DataNum = reader.read<u32>();
        data.TextureSet.VertexIndex = reader.read<u32>();
        data.RectMHXR[0] = reader.read<f32>();
        data.RectMHXR[1] = reader.read<f32>();
        data.RectMHXR[2] = reader.read<f32>();
        data.RectMHXR[3] = reader.read<f32>();
        data.TextureSet.Data[0] = data.RectMHXR[0];
        data.TextureSet.Data[1] = data.RectMHXR[1];
        reader.read<u64>(); // pad
        break;
    }
    default:
        data.FullData[0] = reader.read<u64>();
        data.FullData[1] = reader.read<u64>();
        break;
    }

    reader.seek_absolute(old_pos);
    return data;
}

void GUIExtendData::write(KeyValueBuffers& kv_buffers, ObjectType type) const {
    constexpr auto as_bytes = [](const auto& data) {
        return std::span(reinterpret_cast<const u8*>(&data), sizeof data);
    };
    
    switch (type) {
    case ObjectType::cGUIObjChildAnimationRoot:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot.GUIResourceId).begin(), as_bytes(ChildAnimationRoot.GUIResourceId).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot.AnimationId).begin(), as_bytes(ChildAnimationRoot.AnimationId).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot._pad).begin(), as_bytes(ChildAnimationRoot._pad).end());
        break;
    case ObjectType::cGUIObjTextureSet:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.DataNum).begin(), as_bytes(TextureSet.DataNum).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.VertexIndex).begin(), as_bytes(TextureSet.VertexIndex).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.Data[0]).begin(), as_bytes(TextureSet.Data[0]).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.Data[1]).begin(), as_bytes(TextureSet.Data[1]).end());

        for (const auto& uv : UVs) {
            kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(uv).begin(), as_bytes(uv).end());
        }
        break;
    default:
        break;
    }
}

void GUIExtendData::write_mhxr(KeyValueBuffers& kv_buffers, ObjectType type) const {
    constexpr auto as_bytes = [](const auto& v) {
        return std::span(reinterpret_cast<const u8*>(&v), sizeof v);
    };

    switch (type) {
    case ObjectType::cGUIObjChildAnimationRoot:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot.GUIResourceId).begin(), as_bytes(ChildAnimationRoot.GUIResourceId).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot.AnimationId).begin(), as_bytes(ChildAnimationRoot.AnimationId).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot._pad).begin(), as_bytes(ChildAnimationRoot._pad).end());
        break;
    case ObjectType::cGUIObjTextureSet:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.DataNum).begin(), as_bytes(TextureSet.DataNum).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.VertexIndex).begin(), as_bytes(TextureSet.VertexIndex).end());
        for (const auto f : RectMHXR) {
            kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(f).begin(), as_bytes(f).end());
        }
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet._pad).begin(), as_bytes(TextureSet._pad).end());
        break;
    default:
        break;
    }
}

void GUIExtendData::write_mhgu(KeyValueBuffers& kv_buffers, ObjectType type) const {
    constexpr auto as_bytes = [](const auto& data) {
        return std::span(reinterpret_cast<const u8*>(&data), sizeof data);
    };

    switch (type)
    {
    case ObjectType::cGUIObjChildAnimationRoot:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(ChildAnimationRoot.AnimationId).begin(), as_bytes(ChildAnimationRoot.AnimationId).end());
        break;
    case ObjectType::cGUIObjTextureSet:
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.DataNum).begin(), as_bytes(TextureSet.DataNum).end());
        kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(TextureSet.VertexIndex).begin(), as_bytes(TextureSet.VertexIndex).end());
        for (const auto& uv : UVs) {
            kv_buffers.ExtendData.insert(kv_buffers.ExtendData.end(), as_bytes(uv).begin(), as_bytes(uv).end());
        }
        break;
    }
}
