#include "pch.h"
#include "App.h"
#include "BinaryReader.h"
#include "BinaryWriter.h"
#include "Console.h"
#include "GUIFile.h"
#include "Settings.h"

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <string_view>

#include <fmt/format.h>
#include <spdlog/spdlog.h>

namespace {

// Anything that reaches this point means the process is about to die, so the message
// goes to the log file and to a dialog the user can actually read.
void report_fatal(const std::string& message) {
    spdlog::critical("{}", message);
    spdlog::default_logger_raw()->flush();

    const std::string text = fmt::format("{}\n\nDetails were written to:\n{}",
        message, Console::get()->get_log_path());

    MessageBoxA(nullptr, text.c_str(), "MHXR GUI Editor - Fatal Error", MB_ICONERROR | MB_OK);
}

// Access violations and friends never become C++ exceptions, so they need a SEH filter
LONG WINAPI seh_filter(EXCEPTION_POINTERS* info) {
    std::string message = "Unhandled system exception";

    if (info && info->ExceptionRecord) {
        const DWORD code = info->ExceptionRecord->ExceptionCode;
        const auto address = reinterpret_cast<std::uintptr_t>(info->ExceptionRecord->ExceptionAddress);

        message = fmt::format("Unhandled system exception 0x{:08X} at 0x{:X}", code, address);
    }

    report_fatal(message);
    return EXCEPTION_EXECUTE_HANDLER;
}

void terminate_handler() {
    report_fatal("std::terminate called: an exception was never caught");

    // A terminate handler must not return, and the stack may already be gone
    std::_Exit(1);
}

void install_crash_handlers() {
    SetUnhandledExceptionFilter(seh_filter);
    std::set_terminate(terminate_handler);
}

int run_roundtrip(const std::filesystem::path& in_path, const std::filesystem::path& out_path) {
    try {
        GUIFile gui{};

        BinaryReader reader(in_path);
        gui.load_from(reader);

        BinaryWriter writer(out_path);

        // Use the real configuration (Config.toml) - the key value de-duplication flags
        // in there have a direct effect on the size of the generated buffers.
        Settings settings{};
        settings.load();

        if (!gui.save_to(writer, settings)) {
            spdlog::error("roundtrip failed: save refused to write the file");
            std::fprintf(stderr, "roundtrip failed: %s\n", "save refused to write the file");
            return 1;
        }

        std::printf("roundtrip ok: %s -> %s\n", in_path.string().c_str(), out_path.string().c_str());
        return 0;
    }
    catch (const std::exception& e) {
        spdlog::error("roundtrip failed: {}", e.what());
        std::fprintf(stderr, "roundtrip failed: %s\n", e.what());
        return 1;
    }
}

} // namespace

int WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // Make the process DPI aware: without this, Windows stretches the window and the ImGui
    // cursor position no longer matches what is on screen (cursor "drift" towards the bottom).
    SetProcessDPIAware();

    const auto& console = Console::get();
#if defined(_DEBUG)
    console->initialize(true);
#else
    // No console window in release, but the log file is always written
    console->initialize(false);
#endif

    install_crash_handlers();

    spdlog::info("MHXR GUI Editor starting, log file: {}", console->get_log_path());

    // Headless round-trip check (no UI):
    //   "MHXR gui editor.exe" --roundtrip <input.gui> <output.gui>
    // Loads a file and writes it straight back out. Used to verify that saving is
    // byte-for-byte lossless by comparing the two files afterwards.
    if (__argc >= 4 && std::string_view(__argv[1]) == "--roundtrip") {
        const int result = run_roundtrip(std::filesystem::path(__argv[2]), std::filesystem::path(__argv[3]));
        console->shutdown();
        return result;
    }

    int result = 1;

    try {
        App app;
        result = app.run();
        spdlog::info("App::run() returned {}", result);
    }
    catch (const std::exception& e) {
        report_fatal(fmt::format("Unhandled exception: {}", e.what()));
    }
    catch (...) {
        report_fatal("Unhandled exception of unknown type");
    }

    console->shutdown();
    return result;
}
