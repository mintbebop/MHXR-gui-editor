#include "pch.h"
#include "GUIObject.h"
#include "GUIVertex.h"

#include <fmt/format.h>


GUIObject GUIObject::read(BinaryReader& reader, const GUIHeader& header) {
    GUIObject obj = {
        .ID = reader.read<u32>(),
        .InitParamNum = reader.read<u8>(),
        .AnimateParamNum = reader.read_skip<u8>(2),
        .NextIndex = reader.read<s32>(),
        .ChildIndex = reader.read<s32>(),
        .Name = reader.abs_offset_read_string(header.stringOffset + reader.read_skip<u32>(4)),
        .Type = reader.read_skip<ObjectType>(4),
        .InitParamIndex = reader.read_skip<u32>(4),
        .ObjectSequenceIndex = reader.read_skip<u32>(4),
        .ExtendDataOffset = reader.read_skip<s32>(4),
    };

    obj.ExtendData = GUIExtendData::read(reader, obj.Type, obj.ExtendDataOffset, header);

    return obj;
}

GUIObject GUIObject::read_mhgu(BinaryReader& reader, const GUIHeaderMHGU& header) {
    GUIObject obj = {
        .ID = reader.read<u32>(),
        .InitParamNum = reader.read<u8>(),
        .AnimateParamNum = reader.read_skip<u8>(2),
        .NextIndex = reader.read<s32>(),
        .ChildIndex = reader.read<s32>(),
        .Name = reader.abs_offset_read_string(header.stringOffset + reader.read<u32>()),
        .Type = reader.read<ObjectType>(),
        .InitParamIndex = reader.read<u32>(),
        .ObjectSequenceIndex = reader.read<u32>(),
        .ExtendDataOffset = reader.read<s32>(),
    };

    obj.ExtendData = GUIExtendData::read_mhgu(reader, obj.Type, obj.ExtendDataOffset, header);

    return obj;
}

GUIObject GUIObject::read_mhxr(BinaryReader& reader, const GUIHeader& header) {
    // MHXR object layout == MHW object layout (56B, u64 type/index fields)
    GUIObject obj = {
        .ID = reader.read<u32>(),
        .InitParamNum = reader.read<u8>(),
        .AnimateParamNum = reader.read_skip<u8>(2),
        .NextIndex = reader.read<s32>(),
        .ChildIndex = reader.read<s32>(),
        .Name = reader.abs_offset_read_string(header.stringOffset + reader.read_skip<u32>(4)),
        .Type = reader.read_skip<ObjectType>(4),
        .InitParamIndex = reader.read_skip<u32>(4),
        .ObjectSequenceIndex = reader.read_skip<u32>(4),
        .ExtendDataOffset = reader.read_skip<s32>(4),
    };

    obj.ExtendData = GUIExtendData::read_mhxr(reader, obj.Type, obj.ExtendDataOffset, header);

    return obj;
}

void GUIObject::write(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
	writer.write(ID);
    writer.write(InitParamNum);
    writer.write(AnimateParamNum);
	writer.write<u16>(0);
    writer.write(NextIndex);
    writer.write(ChildIndex);
	writer.write(buffer.append_no_duplicate(Name));
	writer.write(static_cast<u64>(Type));
	writer.write<u64>(InitParamIndex);
	writer.write<u64>(ObjectSequenceIndex);

    if (ExtendDataOffset != -1) {
        writer.write<s64>(kv_buffers.ExtendData.size());
        ExtendData.write(kv_buffers, Type);
    } else {
        writer.write_tuple<s32, s32>({ -1, 0 });
    }
}

void GUIObject::write_mhxr(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
    // Mirror of read_mhxr: 56B, every field occupies an 8 byte slot (value in the low 32 bits)
    writer.write(ID);
    writer.write(InitParamNum);
    writer.write(AnimateParamNum);
    writer.write<u16>(0); // padding
    writer.write(NextIndex);
    writer.write(ChildIndex);
    writer.write(static_cast<u32>(buffer.append_no_duplicate(Name)));
    writer.write<u32>(0);
    writer.write(static_cast<u32>(Type));
    writer.write<u32>(0);
    writer.write(InitParamIndex);
    writer.write<u32>(0);
    writer.write(ObjectSequenceIndex);
    writer.write<u32>(0);

    if (ExtendDataOffset != -1) {
        writer.write(static_cast<s32>(kv_buffers.ExtendData.size()));
        writer.write<u32>(0);
        ExtendData.write_mhxr(kv_buffers, Type);
    } else {
        writer.write<s32>(-1);
        writer.write<u32>(0);
    }
}

void GUIObject::write_mhgu(BinaryWriter& writer, StringBuffer& buffer, KeyValueBuffers& kv_buffers) const {
    writer.write(ID);
    writer.write(InitParamNum);
    writer.write(AnimateParamNum);
    writer.write<u16>(0);
    writer.write(NextIndex);
    writer.write(ChildIndex);
    writer.write((u32)buffer.append_no_duplicate(Name));
    writer.write(Type);
    writer.write(InitParamIndex);
    writer.write(ObjectSequenceIndex);

    if (ExtendDataOffset != -1) {
        writer.write((u32)kv_buffers.ExtendData.size());
        ExtendData.write(kv_buffers, Type);
    } else {
        writer.write<s32>(-1);
    }
}

std::string GUIObject::get_preview(u32 index) const {
	if (index == 0xFFFFFFFF) {
		return fmt::format("Object<<C FFA3D7B8>{}</C>>: <C FFB0C94E>{} </C><C FFFEDC9C>{}</C>", ID, enum_to_string(Type), Name);
	}

    return fmt::format("[<C FFA3D7B8>{}</C>] Object<<C FFA3D7B8>{}</C>>: <C FFB0C94E>{} </C><C FFFEDC9C>{}</C>", index, ID, enum_to_string(Type), Name);
}
