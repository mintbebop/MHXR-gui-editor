#pragma once

#include "dti_types.h"
#include "BinaryReader.h"
#include "BinaryWriter.h"
#include "Settings.h"

#include "GUIAnimation.h"
#include "GUISequence.h"
#include "GUIObject.h"
#include "GUIObjectSequence.h"
#include "GUIInitParam.h"
#include "GUIParam.h"
#include "GUIKey.h"
#include "GUIInstance.h"
#include "GUIFlow.h"
#include "GUIFlowProcess.h"
#include "GUITexture.h"
#include "GUIFontFilter.h"
#include "GUIMessage.h"
#include "GUIResource.h"
#include "GUIGeneralResource.h"
#include "GUIVertex.h"

#include <array>
#include <vector>


class GUIEditor;

class GUIFile {
public:
	GUIFile();

	void load_from(BinaryReader& stream);
    void load_resources(
		const std::string& chunk_path, 
		const std::string& native_path,
        const std::string& arcfs_path,
		ID3D11Device* device, 
		ID3D11DeviceContext* context
	);

	void run_data_usage_analysis(bool log_overlapping_offsets = false) const;

    // Returns false when nothing was written, so the caller can keep the original file
    [[nodiscard]] bool save_to(BinaryWriter& stream, const Settings& settings) const;

	enum class Version {
		MHW = 144150,
		MHGU = 141077,
		MHXR = 139796,
	};

	Version get_version() const { return static_cast<Version>(m_header.guiVersion); }
    bool is_mhgu() const { return get_version() == Version::MHGU; }
    bool is_mhxr() const { return get_version() == Version::MHXR; }

    void insert_animation(GUIAnimation anim, s32 index = -1, bool update_indices = true);
    void insert_sequence(GUISequence seq, s32 index = -1, bool update_indices = true);
    void insert_object(GUIObject obj, s32 index = -1, bool update_indices = true);
    void insert_object_sequence(GUIObjectSequence objseq, s32 index = -1, bool update_indices = true);
    void insert_init_param(GUIInitParam param, s32 index = -1, bool update_indices = true);
    void insert_param(GUIParam param, s32 index = -1, bool update_indices = true);
    void insert_key(GUIKey key, s32 index = -1, bool update_indices = true);
    void insert_instance(GUIInstance inst, s32 index = -1, bool update_indices = true);
    void insert_flow(GUIFlow flow, s32 index = -1, bool update_indices = true);
    void insert_flow_process(GUIFlowProcess flow, s32 index = -1, bool update_indices = true);
    void insert_texture(GUITexture tex, s32 index = -1, bool update_indices = true);
    void insert_font_filter(std::shared_ptr<GUIFontFilter> filter, s32 index = -1, bool update_indices = true);

    // Snapshot of the whole editable model - the universal undo mechanism.
    // Covers EVERY field (params, strings, types, indices...) without per-widget wiring.
    // (Defined near the end of this class, after the MHXR-only GUIFont struct.)
    void push_undo_snapshot();
    [[nodiscard]] bool undo_available() const { return !m_undo_stack.empty(); }
    [[nodiscard]] size_t undo_depth() const { return m_undo_stack.size(); }
    [[nodiscard]] bool restore_last_undo();

    // A single edited field, ready to be patched into the file
    struct FieldChange {
        std::string Path;
        std::string OldValue;
        std::string NewValue;
        u64 Offset = 0;
        std::vector<u8> Bytes;
        int Risk = 0; // 0 = low, 1 = medium, 2 = high
    };

    // Original file bytes, kept so that saving can be done as a patch on top of the
    // original file instead of a full re-serialization.
    std::vector<u8> m_original;
    mutable std::vector<FieldChange> m_changes;

    // Byte snapshots of every parameter value at load time, used to detect edits on save
    std::vector<std::vector<u8>> m_param_value_snapshot;

    struct ModelSnapshot;

    void restore_model(const ModelSnapshot& snapshot);

    void snapshot_param_values();
    void diff_param_values() const;

    void record_u32(const std::string& path, u64 offset, u32 old_value, u32 new_value, int risk = 0);
    void record_f32(const std::string& path, u64 offset, f32 old_value, f32 new_value, int risk = 0);

    // Absolute file offset of an entry inside a section (entry sizes verified against real files)
    [[nodiscard]] u64 object_offset(u32 index) const { return m_header.objectOffset + index * 56; }
    [[nodiscard]] u64 instance_offset(u32 index) const { return m_header.instanceOffset + index * 56; }
    [[nodiscard]] u64 flow_offset(u32 index) const { return m_header.flowOffset + index * 32; }
    [[nodiscard]] u64 flow_process_offset(u32 index) const { return m_header.flowProcessOffset + index * 48; }
    [[nodiscard]] u64 key_offset(u32 index) const { return m_header.keyOffset + index * 16; }
    [[nodiscard]] u64 font_offset(u32 index) const { return m_header.fontOffset + index * 24; }
    [[nodiscard]] u64 vertex_offset(u32 index) const { return m_header.vertexOffset + index * 24; }
    void clear_changes();
    [[nodiscard]] bool has_changes() const { return !m_changes.empty(); }
    [[nodiscard]] const std::vector<FieldChange>& get_changes() const { return m_changes; }

    void set_view_size(u32 width, u32 height);

	[[nodiscard]] u32 get_width() const {
        return is_mhgu() ? m_header_mhgu.viewSize_Width : m_header.viewSize_Width;
	}

	[[nodiscard]] u32 get_height() const {
		return is_mhgu() ? m_header_mhgu.viewSize_Height : m_header.viewSize_Height;
	}

    void erase_keys(u32 index, u32 count = 1, bool update_indices = true);

    template<class T> [[nodiscard]] u32 get_unused_id(const std::vector<T>& vec) const {
        return std::ranges::max_element(vec, [](const T& a, const T& b) { return a.ID < b.ID; })->ID + 1;
    }

	template<class T>
    GUIParam* find_param(const T& thing, std::string_view name) {
        const auto params = get_params(thing);
        const auto p = std::ranges::find_if(params, [&](const GUIParam& param) {
            return param.Name == name;
        });

        return p != params.end() ? &*p : nullptr;
    }

	template<class T>
    GUIInitParam* find_init_param(const T& thing, std::string_view name) {
		const auto init_params = get_init_params(thing);
		const auto p = std::ranges::find_if(init_params, [&](const GUIInitParam& param) {
			return param.Name == name;
		});

		return p != init_params.end() ? &*p : nullptr;
    }

	template<class T>
    std::span<GUIParam> get_params(const T& thing) {
        return std::span<GUIParam>(
            m_params.data() + thing.ParamIndex,
            thing.ParamNum
        );
    }

	template<class T>
    std::span<GUIInitParam> get_init_params(const T& thing) {
        return std::span<GUIInitParam>(
            m_init_params.data() + thing.InitParamIndex,
            thing.InitParamNum
        );
    }

	friend class GUIEditor;
	friend class Editor;

private:
    u32 get_animation_object_count(u32 anim_index) const;

private:
	union {
		GUIHeader m_header{};
		GUIHeaderMHGU m_header_mhgu;
	};

	std::array<char, 4> m_magic{};
	u32 m_version = 0;
	u32 m_attr = 0;
	time_t m_revision_time = 0;
	u32 m_instance_id = 0;
	u32 m_flow_id = 0;
	u32 m_variable_id = 0;
	u32 m_start_instance_index = 0;

	std::vector<GUIAnimation> m_animations;
	std::vector<GUISequence> m_sequences;
	std::vector<GUIObject> m_objects;
	std::vector<GUIObjectSequence> m_obj_sequences;
	std::vector<GUIInitParam> m_init_params;
	std::vector<GUIParam> m_params;
	std::vector<GUIKey> m_keys;
	std::vector<GUIInstance> m_instances;
	std::vector<GUIFlow> m_flows;
	std::vector<GUIFlowProcess> m_flow_processes;
	std::vector<GUITexture> m_textures;
	std::vector<std::shared_ptr<GUIFontFilter>> m_font_filters;
	std::vector<GUIMessage> m_messages;
	std::vector<GUIResource> m_resources;
	std::vector<GUIGeneralResource> m_general_resources;
    std::vector<GUIVertex> m_vertices;
	std::vector<size_t> m_root_instances;

	// MHXR (Monster Hunter Explore) only
	struct GUIFont {
		u32 ID;
		std::string Path;
	};
	std::vector<GUIFont> m_fonts;

    // Snapshot of the whole editable model - the universal undo mechanism.
    // Covers EVERY field (params, strings, types, indices...) without per-widget wiring.
    struct ModelSnapshot {
        std::vector<GUIAnimation> animations;
        std::vector<GUISequence> sequences;
        std::vector<GUIObject> objects;
        std::vector<GUIObjectSequence> obj_sequences;
        std::vector<GUIInitParam> init_params;
        std::vector<GUIParam> params;
        std::vector<GUIKey> keys;
        std::vector<GUIInstance> instances;
        std::vector<GUIFlow> flows;
        std::vector<GUIFlowProcess> flow_processes;
        std::vector<std::shared_ptr<GUIFontFilter>> font_filters;
        std::vector<GUIMessage> messages;
        std::vector<GUIResource> resources;
        std::vector<GUIGeneralResource> general_resources;
        std::vector<GUIFont> fonts;
        std::vector<GUIVertex> vertices;
        GUIHeader header;
    };

    std::vector<ModelSnapshot> m_undo_stack;

    // MHXR only: sections that are not parsed yet. Their raw bytes are kept so that
    // saving a file back out is lossless (they would otherwise be dropped).
    std::vector<u8> m_raw_flow_input;
    std::vector<u8> m_raw_flow_switch;
    std::vector<u8> m_raw_flow_function;
    std::vector<u8> m_raw_action;
    std::vector<u8> m_raw_input_condition;
    std::vector<u8> m_raw_switch_operator;
    std::vector<u8> m_raw_switch_condition;
    std::vector<u8> m_raw_variable;
};

