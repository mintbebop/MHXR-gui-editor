#include "pch.h"
#include "I18n.h"

#include <toml++/toml.h>
#include <spdlog/spdlog.h>

#include <filesystem>
#include <unordered_map>
#include <unordered_set>

namespace {
    constexpr const char* LANG_DIR = "lang";
    constexpr const char* FALLBACK_LANGUAGE = "en";

    std::unordered_map<std::string, std::string> g_tables[2]; // 0 = zh, 1 = en
    std::unordered_map<std::string, std::wstring> g_wide_cache;
    std::unordered_set<std::string> g_missing_keys;
    std::string g_language = "zh";

    int table_index(const std::string& language) {
        return language == "en" ? 1 : 0;
    }

    void load_table(const std::string& language) {
        const std::filesystem::path path = std::filesystem::path(LANG_DIR) / (language + ".toml");

        if (!std::filesystem::exists(path)) {
            spdlog::error("Missing language file: {}", path.string());
            return;
        }

        try {
            const auto table = toml::parse_file(path.string());

            for (const auto& [key, value] : table) {
                if (const auto text = value.value<std::string>()) {
                    g_tables[table_index(language)][std::string(key.str())] = *text;
                }
            }
        }
        catch (const std::exception& e) {
            spdlog::error("Failed to parse {}: {}", path.string(), e.what());
        }
    }

    std::wstring to_wide(const std::string& text) {
        if (text.empty()) {
            return {};
        }

        const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
        if (length <= 0) {
            return {};
        }

        std::wstring result(static_cast<size_t>(length), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length);

        return result;
    }
}

void I18n::init(const std::string& language) {
    load_table("zh");
    load_table("en");

    g_wide_cache.clear();
    g_language = language;
}

void I18n::set_language(const std::string& language) {
    if (g_language == language) {
        return;
    }

    // Cached wide strings belong to the previous language
    g_wide_cache.clear();
    g_language = language;
}

const std::string& I18n::current_language() {
    return g_language;
}

const char* I18n::T(const char* key) {
    const auto& table = g_tables[table_index(g_language)];

    if (const auto it = table.find(key); it != table.end()) {
        return it->second.c_str();
    }

    const auto& fallback = g_tables[table_index(FALLBACK_LANGUAGE)];
    if (const auto it = fallback.find(key); it != fallback.end()) {
        return it->second.c_str();
    }

    // Warn once per key, this runs every frame
    if (g_missing_keys.insert(key).second) {
        spdlog::warn("Missing translation for key: {}", key);
    }

    return key;
}

const wchar_t* I18n::TW(const char* key) {
    const char* text = T(key);

    if (const auto it = g_wide_cache.find(text); it != g_wide_cache.end()) {
        return it->second.c_str();
    }

    return g_wide_cache.emplace(text, to_wide(text)).first->second.c_str();
}
