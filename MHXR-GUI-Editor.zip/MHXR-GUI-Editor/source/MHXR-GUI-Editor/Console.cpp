#include "pch.h"
#include "Console.h"

#include <corecrt_io.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/basic_file_sink.h>

#include <filesystem>
#include <memory>

std::shared_ptr<Console> Console::m_instance = std::make_shared<Console>();

const std::shared_ptr<Console>& Console::get() {
    return m_instance;
}

// The log has to sit next to the exe: the working directory differs depending on how
// the editor is started and is not always writable.
static std::string make_log_path() {
    char path[MAX_PATH]{};
    const DWORD len = GetModuleFileNameA(nullptr, path, MAX_PATH);

    if (len > 0 && len < MAX_PATH) {
        return (std::filesystem::path(path).parent_path() / "editor.log").string();
    }

    return "editor.log";
}

void Console::initialize(const bool allocate_console) {
    m_log_path = make_log_path();

    if (allocate_console) {
        AllocConsole();

        (void)freopen_s(reinterpret_cast<FILE**>(stdin), "CONIN$", "r", stdin);
        (void)freopen_s(reinterpret_cast<FILE**>(stdout), "CONOUT$", "w", stdout);
        (void)freopen_s(reinterpret_cast<FILE**>(stderr), "CONOUT$", "w", stderr);

        // Allow selecting and copying log text with the mouse
        if (const HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE); output != INVALID_HANDLE_VALUE) {
            DWORD mode = 0;
            if (GetConsoleMode(output, &mode)) {
                mode = (mode | ENABLE_QUICK_EDIT_MODE | ENABLE_EXTENDED_FLAGS) & ~ENABLE_MOUSE_INPUT;
                SetConsoleMode(output, mode);
            }
        }
    }

    const auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>(m_log_path, true);

    if (allocate_console) {
        const auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
        m_logger = std::make_shared<spdlog::logger>("console", spdlog::sinks_init_list{ console_sink, file_sink });
    } else {
        m_logger = std::make_shared<spdlog::logger>("console", spdlog::sinks_init_list{ file_sink });
    }

    spdlog::set_default_logger(m_logger);

    // The process can die at any moment, so everything worth reading must be on disk
    spdlog::flush_on(spdlog::level::warn);
}

void Console::shutdown() {
    if (m_logger) {
        m_logger->flush();
    }

    m_logger.reset();
    spdlog::drop("console");
    FreeConsole();
}
