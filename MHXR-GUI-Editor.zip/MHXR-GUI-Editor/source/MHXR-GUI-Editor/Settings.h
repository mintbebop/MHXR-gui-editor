#pragma once

#include <string>

// Current UI language ("zh" or "en"), set by Settings::load()
inline std::string g_ui_language;

// Bump when the default dock layout changes so stale imgui.ini state gets rebuilt
inline constexpr int CURRENT_LAYOUT_VERSION = 2;

// Simple bilingual helper
inline const char* Tr(const char* zh, const char* en) {
    return g_ui_language == "zh" ? zh : en;
}

struct Settings {
    static constexpr const char* const DEFAULT_SETTINGS_FILE = "Config.toml";

    Settings();

    bool load();
    bool save();

    std::string ChunkPath;
    std::string NativePath;
    std::string ArcfsPath;
    std::string Theme;
    std::string Language;
    int LayoutVersion = 0;

    // Base size in pixels of every UI font, pick a larger one on high DPI screens
    float FontSize = 16.0f;

    bool AllowMultipleKV8References;
    bool AllowMultipleKV32References;
    bool AllowMultipleKV128References;

    bool AutoAdjustKeyFrames;
    bool AutoBackup = true;
};

